<?php include_once "includes/header.php";
 include_once "js/tiempo_alert.js";
date_default_timezone_set('America/Santiago');
include "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "animal";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}

  include "../conexion.php";
    $id_animal = $_REQUEST['id_animal'];

      $query2 = mysqli_query($conexion, "SELECT * FROM animal WHERE id_animal = $id_animal");
         $result2 = mysqli_num_rows($query2);
           if ($result2 > 0) {
                            while ($data2 = mysqli_fetch_assoc($query2)) { 



$Observaciones = mysqli_query($conexion, "SELECT AVG(nota_observacion) FROM observacion WHERE id_animal = $id_animal");
$totalO = mysqli_fetch_all($Observaciones);





                                ?>
                               
                     




<div class="d-sm-flex align-items-center justify-content-between mb-4">

  <h1 class="h3 mb-0 text-gray">Panel Observación de: <p style="color:#006110";><b>DIIO: CL SAG </b> &nbsp;<?php echo $data2['diio']; }} ?></p></h1><?php echo isset($alert) ? $alert : ''; ?>
   <a class="col-xl-3 col-md-6 mb-4" href="animal.php">
            <div class="card border-left-success shadow h-100 py-2 bg-success">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">promedio de Nota en Observaciones</div>
                            <div class="h5 mb-0 font-weight-bold text-white"><?php echo $totalO[0][0]; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class=" text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div> 
<a href="animal.php"><button class="btn btn-primary" type="button" style="background-color: #006110;" >Animal</button></a>
</div></br>
<div class="col-lg-12">




              <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered mt-2" id="tbl">
                    <thead class="thead-dark">
                        <tr>
                        
                            <th>NOMBRE</th>
                            <th>FOTO</th>
                            <th>DESCRIPCIÓN</th>
                            <th>FECHA OBSERVACIÓN</th>
                            <th>NOTA OBSERVACIÓN</th>
                            <th>FECHA INGRESO</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        $query = mysqli_query($conexion, "SELECT * FROM observacion WHERE id_animal = $id_animal");
                        $result = mysqli_num_rows($query);
                        if ($result > 0) {
                            while ($data = mysqli_fetch_assoc($query)) { ?>
                                <tr>

                                    <td><?php echo $data['nombre']; ?></td>
                                    <td><img width="200" height="100" src="<?php echo $data['foto']; ?>">   </td>
                                    <td><?php echo $data['descripcion']; ?></td>
                                    <td><?php echo $data['fecha_observacion']; ?></td>
                                    <td><?php echo $data['nota_observacion']; ?></td>
                                    <td><?php echo $data['fecha_ingreso']; ?></td>       
                                   <td>
                                        <a href="editar_ver_observaciones.php?id_observacion=<?php echo $data['id_observacion']; ?>" class="btn btn-success" style="background-color: #006110;"><i class='fas fa-edit'></i> Editar</a>
                                    </td>    
                                    <?php } ?>
                                </tr>
                        <?php }
                        ?>
                    </tbody>
                </table>
            </div>

        </div>        
   <?php include_once "includes/footer.php"; ?>