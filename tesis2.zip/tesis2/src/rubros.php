
<?php include_once "includes/header.php";
 include_once "js/tiempo_alert.js";
date_default_timezone_set('America/Santiago');
include "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "rubros";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
if (!empty($_POST)){
    $alert = "";
    if (empty($_POST['nombre_rubro'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        El campo es obligatorio
        </div>';
    } else {
        $nombre_rubro   = $_POST['nombre_rubro'];

        $query = mysqli_query($conexion, "SELECT * FROM rubro where nombre_rubro = '$nombre_rubro'");

        $result = mysqli_fetch_array($query);
        if ($result > 0) {
            $alert = '<div class="alert alert-warning" role="alert">
                        El nombre ya existe
                    </div>';
        } else {
            $query_insert = mysqli_query($conexion, "INSERT INTO rubro(nombre_rubro) values ('$nombre_rubro')");
            if ($query_insert) {
                $alert = '<div class="alert alert-primary" role="alert">
                            Rubro registrado
                        </div>';
            } else {
                $alert = '<div class="alert alert-danger" role="alert">
                        Error al registrar el rubro
                    </div>';
            }
        }
    }
}
?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray">Panel de Rubro</h1><?php echo isset($alert) ? $alert : ''; ?>
    </div>
    <div>
<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#nuevo_rubro" style="background-color: #006110;"><i class="fas fa-plus"></i></button>

</div>
</br>
<div id="nuevo_rubro" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header  text-white" style="background-color: #006110;">
                <h5 class="modal-title" id="my-modal-title" >Nuevo Rubro</h5>
         <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="post" autocomplete="off">
                    <?php echo isset($alert) ? $alert : ''; ?>

                     <div class="form-group">
                            <label>Rubro:</label>
                            <input type="text" name="nombre_rubro" class="form-control"  id="nombre_rubro" placeholder="Ingrese el nombre del rubro. " minlength="4" maxlength="20" required>
                        </div>
                         
                    <input type="submit" value="Registrar" class="btn btn-primary" style="background-color: #006110;">
                </form>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered mt-2" id="tbl">
                    <thead class="thead-dark">
                        <tr>
 
                            <th>NOMBRE RUBRO</th>
                            <th></th>     
                        </tr>
                    </thead>
                    <style>
    #heading { color: #73FF00; }
    #heading2 { color: #FF0000; }
  </style>
                            <tbody>
             <?php
                        include "../conexion.php";

                        $query = mysqli_query($conexion, "SELECT * FROM  rubro");
                        $result = mysqli_num_rows($query);
                        if ($result > 0) {
                            while ($data = mysqli_fetch_assoc($query)) { ?>
                                <tr>
                           
                                    <td><?php echo $data['nombre_rubro']; ?></td>                                    
                                   <td>
                                        <a href="editar_rubros.php?id_rubro=<?php echo $data['id_rubro']; ?>" class="btn btn-success" style="background-color: #006110;"><i class='fas fa-edit'></i> Editar</a>
                                         <form action="eliminar_rubros.php?id_rubro=<?php echo $data['id_rubro']; ?>" method="post" class="confirmar d-inline">
                                    <button class="btn btn-danger" type="submit"><i class='fas fa-trash-alt'></i> </button>
                                         </form>
                                    </td>
                                   
                                    <?php } ?>
                                </tr>

                        <?php }
                        ?>
                    </tbody>

                </table>
            </div>

    </div>
<?php include_once "includes/footer.php"; ?>