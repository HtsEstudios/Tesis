require 'funcs/funcs.php'

if(!empty($_POST))
{
	$email = $mysqli->real_escape_string($_POST['email']);

	if(!idEmail())
	{
		$erro
	}
}