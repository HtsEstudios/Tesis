if (document.getElementById("sales1-chart")) {
    const action = "sales1";
    $.ajax({
        url: 'chart.php',
        type: 'POST',
        data: {
            action
        },
        async: true,
        success: function (response) {
            if (response != 0) {
                var data = JSON.parse(response);
                var fecha_nacimiento = [];
                var id_animal = [];
                for (var i = 0; i < data.length; i++) {
                    fecha_nacimiento.push(data[i]['fecha_nacimiento']);
                    id_animal.push(data[i]['id_animal']);
                   
                }
                try {
                    //Sales chart
                    var ctx = document.getElementById("sales1-chart");
                    if (ctx) {
                        ctx.height = 150;
                        var myChart = new Chart(ctx, {
                            type: 'line',
                            data: {
                                labels: fecha_nacimiento,
                                type: 'line',
                                defaultFontFamily: 'Poppins',
                             
                            },
                           
                                title: {
                                    display: false,
                                    text: 'Normal Legend'
                                }
                            }
                        };
                    }
                } catch (error) {
                    console.log(error);
                }
            }
        },
        error: function (error) {
            console.log(error);
        }