<?php include_once "includes/header.php";
include "../conexion.php";
include_once "js/tiempo_alert.js";
$id_user = $_SESSION['idUser'];
$permiso = "establecimiento";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
if (!empty($_POST)) {
    $alert = "";
    if (empty($_POST['direccion'])|| empty($_POST['numero']) || empty($_POST['region_id'])  || empty($_POST['comuna_id'])|| empty($_POST['provincia_id'])|| empty($_POST['localidad'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        Todo los campos son obligatorios
        </div>';
    } else {
    	$direccion_id				= $_GET['direccion_id'];
    	$direccion                  = $_POST['direccion'];
        $numero                     = $_POST['numero'];
        $region_id                  = $_POST['region_id'];
        $comuna_id                  = $_POST['comuna_id'];
        $provincia_id               = $_POST['provincia_id'];
        $localidad                  = $_POST['localidad'];

   $sql_update = mysqli_query($conexion, "UPDATE direccion_establecimiento SET  direccion = '$direccion',
   																				numero = '$numero',
   																				region_id = '$region_id',
   																				comuna_id = '$comuna_id',
   																				provincia_id = '$provincia_id',
   																				localidad = '$localidad' WHERE direccion_id = $direccion_id");

        $alert = '<div class="alert alert-success" role="alert">direccion Actualizado</div>';
    }
}
if (empty($_REQUEST['direccion_id'])) {
    header("Location: direccion.php");
}
$direccion_id = $_REQUEST['direccion_id'];
$sql = mysqli_query($conexion, "SELECT * FROM direccion_establecimiento WHERE direccion_id = $direccion_id");
$result_sql = mysqli_num_rows($sql);
if ($result_sql == 0) {
    header("Location: direccion.php");
} else {
    if ($data = mysqli_fetch_array($sql)) {
        $direccion_id               = $data['direccion_id'];
        $direccion                  = $data['direccion'];
        $numero                     = $data['numero'];
        $region_id                  = $data['region_id'];
        $comuna_id                  = $data['comuna_id'];
        $provincia_id               = $data['provincia_id'];
        $localidad                  = $data['localidad'];
        
    }

}
?>
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-6 m-auto">
            <div class="card">
                <div class="card-header  text-white" style="background-color: #006110;">
                    Modificar direccion
                </div>
                <div class="card-body">
                    <form class="" action="" method="post">
                    
                   <?php echo isset($alert) ? $alert : ''; ?> 
                  <input type="hidden" name="direccion_id" id="" value="<?php echo $direccion_id; ?>">
                     <div class="form-group">
                        <label for="direccion">direccion</label>
                        <input type="text" class="form-control" placeholder=" direccion" name="direccion" id="direccion" value="<?php echo $direccion; ?>" minlength="4"  maxlength="20" required>
                    </div>
                    <div class="form-group">
                        <label for="numero">numero</label>
                        <input type="number" class="form-control" placeholder="Ingrese numero" name="numero" id="numero" value="<?php echo $numero; ?>" required>
                    </div>
                
                        <div class="form-group">
                          <label for="">region</label>
                            <select name="region_id" id="region_id" class="form-control" value="<?php echo $region_id; ?>">
                        <?php
                        $query_rol1 = mysqli_query($conexion, " select * from regiones");
                        //mysqli_close($conexion);
                        $resultado_rol1 = mysqli_num_rows($query_rol1);
                        if ($resultado_rol1 > 0) {
                            while ($region_id2 = mysqli_fetch_array($query_rol1)) {
                        ?>
                

                                <option value="<?php echo $region_id2["region_id"]; ?>"<?=$region_id2['region_id'] == $region_id ? ' selected="selected"' : '';?>  ><?php echo $region_id2["region"] ?></option>
                               
                        <?php
                            }
                        }
                        ?>
                        </select></div>   



                               
                    <div class="form-group">
                    <label for="comuna_id">comunas</label>
                    <select name="comuna_id" id="comuna_id" class="form-control" value="<?php echo $comuna_id; ?>">
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from comunas");
                   //     mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($comuna_id2 = mysqli_fetch_array($query_rol)) {
                        ?>
                                 <option value="<?php echo $comuna_id2["comuna_id"]; ?>"<?=$comuna_id2['comuna_id'] == $comuna_id ? ' selected="selected"' : '';?>  ><?php echo $comuna_id2["comuna"] ?></option>
                        <?php

                            }
                        }

                        ?>
                      
                    </select></div>


                    <div class="form-group">
                    <label for="provincia_id">provincia</label>
                    <select name="provincia_id" id="provincia_id" class="form-control" value="<?php echo $provincia_id; ?>">
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from provincias");
                        mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($provincia_id2 = mysqli_fetch_array($query_rol)) {
                        ?>
                                <option value="<?php echo $provincia_id2["provincia_id"]; ?>"<?=$provincia_id2['provincia_id'] == $provincia_id ? ' selected="selected"' : '';?>  ><?php echo $provincia_id2["provincia"] ?></option>
                        <?php

                            }
                        }

                        ?>
                      
                    </select></div>
                     <div class="form-group">
                        <label for="localidad">localidad</label>
                        <input type="text" class="form-control" placeholder="Ingrese localidad" name="localidad" id="localidad" value="<?php echo $localidad; ?>" minlength="4"  maxlength="20" required>
                     </div>
                     
                      
                            </br>
                        <button type="submit" class="btn btn-primary" style="background-color: #006110;"><i class="fas fa-user-edit"></i> Editar Animal</button>
                        <a href="direccion.php" class="btn btn-danger">Atras</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
    <?php     include "js/validacion.js";  ?>
<?php include_once "includes/footer.php"; ?>