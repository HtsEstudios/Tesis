<?php 

// Requerimientos de clases externas
require_once 'vendor/autoload.php'; // requerimos el autoloader para cargar todo lo que necesitemos de las librerías de composer
use Verot\Upload\Upload; // es obligatorio usar el namespace para poder cargar la clase con éxito

/**
 * Genera redirección entre rutas
 *
 * @param string $url
 * @return void
 */
function redirect($url) {
  header(sprintf('Location: %s', $url));
  die;
}

///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
//                    LÓGICA DEL PROCESO
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////

// Validamos la existencia del parametro con el archivo
if (!isset($_FILES['file'])) {
  redirect('index.php?error=no-image');
}

$file = $_FILES['file']; // archivo temporal en espera de ser procesado
$path = 'uploads/';      // donde vamos a guardar el archivo

$foo  = new Upload($file);

if (!$foo) {
  redirect('index.php?error=no-uploaded'); // La imagen no se ha subido correctamente, vuelve a intentarlo
}

// save uploaded image with no changes
$foo->process($path);
if ($foo->processed) {
  echo 'Guardamos la imagen original con éxito.<br>';
} else {
  echo sprintf('Error: %s<br>', $foo->error);
}

