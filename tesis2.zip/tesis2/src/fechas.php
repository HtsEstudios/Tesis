<?php include_once "includes/header.php";
 include_once "js/tiempo_alert.js";
include "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "historial";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray">Panel de Registro Ingreso</h1><?php echo isset($alert) ? $alert : ''; ?>
    </div>
        <div class="col-lg-12">
            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered mt-2" id="tbl">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID FECHA</th>
                            <th>FECHA DE INGRESO</th>
                            <th>USUARIO</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include "../conexion.php";


                        $query = mysqli_query($conexion, "SELECT f.id_fecha, f.fecha, u.idusuario, u.usuario FROM  fecha_ingreso f INNER JOIN usuario u ON f.idusuario = u.idusuario ORDER BY id_fecha desc " );
                        $result = mysqli_num_rows($query);
                        if ($result > 0) {
                            while ($data = mysqli_fetch_assoc($query)) { ?>
                                <tr>
                                    <td><?php echo $data['id_fecha']; ?></td>
                                    <td><?php echo $data['fecha']; ?></td>
                                    <td><?php echo $data['usuario']; ?></td>
                              
                                   
                                   
                                    <?php } ?>
                                </tr>

                        <?php }
                        ?>
                    </tbody>

                </table>
            </div>

    </div>

<?php include_once "includes/footer.php"; ?>