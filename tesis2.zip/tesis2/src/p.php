<?php include "includes/header.php"; ?>
<div class="row">
    <div class="col-md-5 mx-auto">
        <div class="card">
            <div class="card-header text-center bg-danger">
                <h4 class="text-white">No tienes permisos</h4>
            </div>
            <div class="card-body">
                <a href="index.php" class="btn btn-block text-white" style="background-color: #006110;">Regresar</a>
            </div>
        </div>
    </div>
</div>
<?php include "includes/footer.php"; ?>