<?php include_once "includes/header.php";
include "../conexion.php";
 include_once "js/tiempo_alert.js";
 include_once "js/validacion.js";
$id_user = $_SESSION['idUser'];
$permiso = "titular";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
if (!empty($_POST)) {
    $alert = "";
    if (empty($_POST['run'])||empty($_POST['nombre'])|| empty($_POST['apellido']) || empty($_POST['genero'])  || empty($_POST['telefono'])|| empty($_POST['celular'])|| empty($_POST['fax']) || empty($_POST['etnia'])|| empty($_POST['email'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        Todo los campos son obligatorios
        </div>';
    } else {
        $run           = $_POST['run'];
        $nombre        = $_POST['nombre'];
        $apellido      = $_POST['apellido'];
        $genero        = $_POST['genero'];
        $telefono      = $_POST['telefono'];
        $celular       = $_POST['celular'];
        $fax           = $_POST['fax'];
        $etnia         = $_POST['etnia'];
        $usuario_indap = $_POST['usuario_indap'];
        $email         = $_POST['email'];

        $query = mysqli_query($conexion, "SELECT * FROM titular where run = '$run'");

        $result = mysqli_fetch_array($query);
        if ($result > 0) {
            $alert = '<div class="alert alert-warning" role="alert">
                        El run ya existe
                    </div>';
        } else {
            $query_insert = mysqli_query($conexion, "INSERT INTO titular(run,nombre,apellido,genero,telefono,celular,fax,etnia,usuario_indap,email) values ('$run', '$nombre', '$apellido', '$genero', '$telefono', '$celular', '$fax', '$etnia',  '$usuario_indap', '$email')");
            if ($query_insert) {
                $alert = '<div class="alert alert-primary" role="alert">
                            titular registrado
                        </div>';
            } else {
                $alert = '<div class="alert alert-danger" role="alert">
                        Error al registrar
                    </div>';
            }
        }
    }
}
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray">Panel de Titular</h1><?php echo isset($alert) ? $alert : ''; ?>
    </div>
<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#nuevo_usuario" style="background-color: #006110;"><i class="fas fa-plus"></i></button>
<div id="nuevo_usuario" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header  text-white" style="background-color: #006110;">
                <h5 class="modal-title" id="my-modal-title" >Nuevo Titular</h5>
         <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="post" autocomplete="off">
                    <?php echo isset($alert) ? $alert : ''; ?>
                    <?php     include_once "js/validacion.js";  ?>
                     <div class="form-group">
                        <label>Run</label>
                        <input type="number" name="run" id="run" class="form-control" placeholder="Ingrese Run sin comas (,) y sin guion(-)" 
                             required>
                       
                    </div>
                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text"  name="nombre" id="nombre"  class="form-control" placeholder="Ingrese Nombre"  maxlength="20" minlength="3" required>
                    </div>
                         <div class="form-group">
                            <label>Apellido:</label>
                            <input type="text" name="apellido" id="apellido" class="form-control"  placeholder="Apellido "   maxlength="20" minlength="3" required>
                        </div>

                        
                      <label for="genero">Género:</label>
                     <div class="form-check">

                          <input class="form-check-input" type="radio" value="1" name="genero" id="genero" required>
                          <label class="form-check-label" for="flexRadioDefault1">
                            MASCULINO
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" value="2" name="genero" id="genero" required>
                          <label class="form-check-label" for="flexRadioDefault2">
                            FEMENINO
                          </label>
                        </div>

                        <div class="form-group">
                            <label>Teléfono:</label>
                            <input type="number" id="telefono"  name="telefono" class="form-control" placeholder="teléfono " required>
                        </div>
                        
                        <div class="form-group">
                            <label>Celular:</label>
                            <input type="number" id="celular" name="celular" class="form-control"  placeholder="celular " required>
                        </div>
                      

                     
                        <div class="form-group">
                            <label>Fax:</label>
                            <input type="number" id="fax" name="fax" class="form-control"   placeholder="fax "   required>
                        </div>
                    

                         <div class="form-group">
                          <label for="etnia">Etnia</label>
                          <select name="etnia" id="etnia" class="form-control" value="<?php echo $etnia; ?>">
                            <option value="1" >MAPUCHE</option>
                            <option value="2">CHILENO</option>
                            <option value="3" >OTRO</option>
                        </select></div>

                        <div class="form-group">
                            <label>Usuario indap:</label>
                            <input type="text" name="usuario_indap" class="form-control" id="usuario_indap" placeholder="usuario indap opcional"  minlength="6" maxlength="9"  >
                        </div>
                         <div class="form-group">
                            <label>Email:</label>
                            <input type="email" name="email" class="form-control" id="email" placeholder="Correo "  maxlength="30" minlength="3" required>
                        </div>
                   
                    <input type="submit" value="Registrar" class="btn btn-primary" style="background-color: #006110;">
                </form>
            </div>
        </div>
    </div>
</div>

        <div class="col-lg-12">
            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered mt-2" id="tbl">
                    <thead class="thead-dark">
                        <tr>
                            <th>RUN</th>
                            <th>NOMBRE</th>
                            <th>APELLIDO</th>
                            <th>GÉNERO</th>
                            <th>ETNIA</th>
                            <th>TELEFONO</th> 
                            <th>CELULAR</th>
                            <th></th>     
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include "../conexion.php";

                        $query = mysqli_query($conexion, "SELECT * FROM  titular");
                        $result = mysqli_num_rows($query);
                        if ($result > 0) {
                            while ($data = mysqli_fetch_assoc($query)) { ?>
                                <tr>
                                    <td><?php echo $data['run']; ?></td>
                                    <td><?php echo $data['nombre']; ?></td>
                                    <td><?php echo $data['apellido']; ?></td>
                                     <td><?php  if ($data['genero'] == 1) {echo "MASCULINO"; } 
                                    else{echo "FEMENINO"; }?> </td>
                                     <td><?php  
                                    if ($data['etnia'] == 1) {
                                        echo "MAPUCHE"; 
                                         } 
                                    elseif ( $data['etnia']==2) {
                                          echo "CHILENO"; 
                                    }
                                    elseif ( $data['etnia']==3) {
                                          echo "OTRO"; 
                                    }?></td>
                                    <td><?php echo $data['telefono']; ?></td>
                                    <td><?php echo $data['celular']; ?></td>
                                   <td>
                                        <a href="config.php?run=<?php echo $data['run']; ?>" class="btn btn-success" style="background-color: #006110;"><i class='fas fa-edit'></i> Editar</a>
                                         <form action="eliminar_titular.php?run=<?php echo $data['run']; ?>" method="post" class="confirmar d-inline">
                                    <button class="btn btn-danger" type="submit"><i class='fas fa-trash-alt'></i> </button>
                                         </form>
                                    </td>
                                   
                                    <?php } ?>
                                </tr>

                        <?php }
                        ?>
                    </tbody>

                </table>
            </div>

    </div>
      <script src="js\validacion3.js" type="text/javascript"></script>
  <script src="js\validacion2.js" type="text/javascript"></script>

<?php include_once "includes/footer.php"; ?>