<?php include_once "includes/header.php";
include "../conexion.php";
 include_once "js/tiempo_alert.js";
$id_user = $_SESSION['idUser'];
$permiso = "establecimiento";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
if (!empty($_POST)) {
    $alert = "";
    if (empty($_POST['direccion'])|| empty($_POST['numero']) || empty($_POST['region_id'])  || empty($_POST['comuna_id'])|| empty($_POST['provincia_id'])|| empty($_POST['localidad'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        Todo los campos son obligatorios
        </div>';
    } else {
       
        $direccion                  = $_POST['direccion'];
        $numero                     = $_POST['numero'];
        $region_id                  = $_POST['region_id'];
        $comuna_id                  = $_POST['comuna_id'];
        $provincia_id               = $_POST['provincia_id'];
        $localidad                  = $_POST['localidad'];



        $query = mysqli_query($conexion, "SELECT * FROM direccion_establecimiento where direccion = '$direccion' AND numero = '$numero'");

        $result = mysqli_fetch_array($query);
        if ($result > 0) {
            $alert = '<div class="alert alert-warning" role="alert">
                        la direccion del establecimiento ya existe
                    </div>';
        } else {
            $query_insert = mysqli_query($conexion, "INSERT INTO direccion_establecimiento(direccion, numero, region_id, comuna_id, provincia_id, localidad) values ('$direccion', '$numero', '$region_id', '$comuna_id', '$provincia_id', '$localidad')");
            if ($query_insert) {
                $alert = '<div class="alert alert-primary" role="alert">
                            direccion registrado
                        </div>';
            } else {
                $alert = '<div class="alert alert-danger" role="alert">
                        Error al registrar
                    </div>';
            }
        }
    }
}
?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray">Direccion del Establecimiento</h1><?php echo isset($alert) ? $alert : ''; ?>
           
    </div>
    <div>
<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#nuevo_direccion" style="background-color: #006110;"><i class="fas fa-plus"></i></button>
<a href="establecimiento.php"><button class="btn" type="button" style="background-color: #EAFE15;" >establecimiento</button></a>
</div></br>

<div id="nuevo_direccion" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header  text-white" style="background-color: #006110;">
                <h5 class="modal-title" id="my-modal-title" >Nuevo direccion del establecimineto</h5>
         <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
         
            <div class="modal-body">
                <form action="" method="post" autocomplete="on">
                   <?php echo isset($alert) ? $alert : ''; ?> 
                     <div class="form-group">
                        <label for="direccion">direccion</label>
                        <input type="text" class="form-control" placeholder=" direccion" name="direccion" id="direccion" minlength="4"  maxlength="20" required>
                    </div>
                    <div class="form-group">
                        <label for="numero">numero</label>
                        <input type="number" class="form-control" placeholder="Ingrese numero" name="numero" id="numero" required>
                    </div>
                        <script type="text/javascript">
                            numero.oninput = function () {
                                        if (this.value.length > 6) {
                                            this.value = this.value.slice(0,6); 
                                        
                                        }
                                    }                         
                        </script>
                
                    <div class="form-group">
                    <label for="region_id">Regiones</label>
                    <select name="region_id" id="region_id" class="form-control" required>
                        <option value="">------seleccione una region------</option>
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from regiones");
                    //    mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($region_id = mysqli_fetch_array($query_rol)) {
                        ?>
                                <option value="<?php echo $region_id["region_id"]; ?>"><?php echo $region_id["region"] ?></option>
                        <?php

                            }
                        }

                        ?>
                      
                    </select></div>
                
                    <div class="form-group">
                    <label for="provincia_id">provincia</label>
                    <select name="provincia_id" id="provincia_id" class="form-control" required>
                        <option value="">------seleccione una provincia------</option>
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from provincias");
                       // mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($provincia_id = mysqli_fetch_array($query_rol)) {
                        ?>
                                <option value="<?php echo $provincia_id["provincia_id"]; ?>"><?php echo $provincia_id["provincia"] ?></option>
                        <?php

                            }
                        }

                        ?>
                      
                    </select></div>
                   
                    <div class="form-group">
                    <label for="comuna_id">comunas</label>
                    <select name="comuna_id" id="comuna_id" class="form-control" required>
                        <option value="">------seleccione una comuna------</option>
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from comunas order by comuna ");
                         mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($comuna_id = mysqli_fetch_array($query_rol)) {
                        ?>
                                <option value="<?php echo $comuna_id["comuna_id"]; ?>"><?php echo $comuna_id["comuna"] ?></option>
                        <?php

                            }
                        }

                        ?>
                      
                    </select></div>



                     <div class="form-group">
                        <label for="localidad">localidad</label>
                        <input type="text" class="form-control" placeholder="Ingrese localidad" name="localidad" id="localidad"  minlength="4"  maxlength="20" required>
                     </div>
                     
                    <input type="submit" value="Registrar" class="btn btn-primary" style="background-color: #006110;">
                </form>
            </div>
        </div>
    </div>
</div>
   


        <div class="col-lg-12">
            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered mt-2" id="tbl">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>DIRECCION</th>
                            <th>NUMERO</th>
                            <th>REGION</th>
                            <th>COMUNA</th> 
                            <th>PROVINCIA</th>
                            <th></th>     
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include "../conexion.php";

                        $query = mysqli_query($conexion, "SELECT d.direccion_id, d.direccion, d.numero, d.region_id, d.provincia_id, d.comuna_id,r.region, c.comuna, p.provincia FROM direccion_establecimiento d INNER JOIN regiones r ON d.region_id = r.region_id INNER JOIN provincias p ON d.provincia_id = p.provincia_id INNER JOIN comunas c ON d.comuna_id = c.comuna_id");

                        $result = mysqli_num_rows($query);
                        if ($result > 0) {
                            while ($data = mysqli_fetch_assoc($query)) { ?>
                                <tr>
                                    <td><?php echo $data['direccion_id']; ?></td>
                                    <td><?php echo $data['direccion']; ?></td>
                                    <td><?php echo $data['numero']; ?></td>
                                    <td><?php echo $data['region']; ?></td>
                                    <td><?php echo $data['comuna']; ?></td>
                                    <td><?php echo $data['provincia']; ?></td>
                                   <td>
                                        <a href="editar_direccion.php?direccion_id=<?php echo $data['direccion_id']; ?>" class="btn btn-success" style="background-color: #006110;"><i class='fas fa-edit'></i> Editar</a>
                                         <form action="eliminar_direccion.php?direccion_id=<?php echo $data['direccion_id']; ?>" method="post" class="confirmar d-inline">
                                    <button class="btn btn-danger" type="submit"><i class='fas fa-trash-alt'></i> </button>
                                         </form>
                                    </td>
                                   
                                    <?php } ?>
                                </tr>

                        <?php }
                        ?>
                    </tbody>

                </table>
            </div>

    </div>
        <?php     include "js/validacion.js";  ?>
<?php include_once "includes/footer.php"; ?>