function change(categorizacion, sub_categorizacion){
    categorizacion = document.getElementById(categorizacion);
    sub_categorizacion = document.getElementById(sub_categorizacion);
    sub_categorizacion.value ="";
    sub_categorizacion.innerHTML = "";
    if(categorizacion.value == "1")
    {
    var optionArray = ["|","1|Infarto",
                          "2|Hemorragia masiva",
                          "3|Lengua Azul",
                          "4|salmonela",
                          "5|tuberculosis",
                          "6|peste bubonica",
                          "7|viruela",
                          "8|fibre aftosa",
                          "9|accidente Mortal o con consecuencia",]; 
} 
else if(categorizacion.value == "2")
{
	var optionArray = ["|","10|AGUILERA",
                              "11|ALDANA",
                              "12|AMPLIACION PETROLERA",
                              "13|ANGEL ZIMBRON",
                              "14|ARENAL",];
                            };

 for(option = 0;option < optionArray.length; option++){
    var pair = optionArray[option].split("|");
    var newOption = document.createElement("option");
    newOption.value = pair[0];
    newOption.innerHTML = pair[1];
    sub_categorizacion.options.add(newOption);
  };    
}