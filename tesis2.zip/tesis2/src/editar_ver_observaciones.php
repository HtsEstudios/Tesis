<?php include_once "includes/header.php";
date_default_timezone_set('America/Santiago');
require_once 'vendor/autoload.php'; // requerimos el autoloader para cargar todo lo que necesitemos de las librerías de composer
use Verot\Upload\Upload;
 include_once "js/tiempo_alert.js";
include "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "animal";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
if (!empty($_POST)){
    $alert = "";
    if (empty($_POST['nombre']) || empty($_POST['descripcion'])|| empty($_POST['fecha_observacion'])|| empty($_POST['nota_observacion'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        Todo los campos son obligatorios
        </div>';
    } else {

    	$id_observacion		= $_GET['id_observacion'];
    	$nombre                = $_POST['nombre'];
        $descripcion           = $_POST['descripcion'];
        $fecha_observacion     = $_POST['fecha_observacion'];
        $nota_observacion      = $_POST['nota_observacion'];
    

   $sql_update = mysqli_query($conexion, "UPDATE observacion SET nombre = '$nombre',
   																 descripcion = '$descripcion',
   																 fecha_observacion = '$fecha_observacion',
   																 nota_observacion = '$nota_observacion'
   																 WHERE id_observacion = $id_observacion");

        $alert = '<div class="alert alert-success" role="alert">observacion Actualizado</div>';
    }
}

if (empty($_REQUEST['id_observacion'])) {
    header("Location: animal.php");
}
$id_observacion = $_REQUEST['id_observacion'];
$sql = mysqli_query($conexion, "SELECT o.id_observacion, o.nombre, o.descripcion, o.fecha_observacion, o.nota_observacion, o.id_animal, a.id_animal,  a.diio FROM observacion o INNER JOIN animal a ON o.id_animal = a.id_animal WHERE id_observacion = $id_observacion");
$result_sql = mysqli_num_rows($sql);
if ($result_sql == 0) {
    header("Location: observacion.php");
} else {
    if ($data = mysqli_fetch_array($sql)) {
        $id_observacion		   = $data['id_observacion'];
    	  $nombre                = $data['nombre'];
        $descripcion           = $data['descripcion'];
        $fecha_observacion     = $data['fecha_observacion'];
        $nota_observacion      = $data['nota_observacion'];
        $id_animal             = $data['id_animal'];  
        $diio             = $data['diio'];
    }
}
?>



<div class="container-fluid">

    <div class="row">
        <div class="col-lg-6 m-auto">
            <div class="card">
                <div class="card-header  text-white" style="background-color: #006110;">
                    Modificar Observacion del DIIO &nbsp;<?php echo $diio; ?>
                </div>
                <div class="card-body">
                    <form class="" action="" method="post">
                        <?php echo isset($alert) ? $alert : ''; ?>
                        <input type="hidden" name="id_observacion" id="" value="<?php echo $id_observacion; ?>">
                         <div class="form-group">

                        <div class="form-group">
                        <label for="nombre">Nombre:</label>
                        <input type="text" class="form-control" placeholder="Ingrese el nombre de la observación" name="nombre" id="nombre" value="<?php echo $nombre; ?>" minlength="3"  maxlength="20" required>
                   	    </div>
                   	        <div class="form-group">
                            <label>Descripción:</label>
                            <input type="text" step="0.01" name="descripcion" class="form-control" id="descripcion" placeholder="Ingrese la descripcion de la observación."  value="<?php echo $descripcion; ?> " minlength="10"  maxlength="300" required>
                        </div>

                            <label for="fecha_observacion">Fecha en la cual se vio la observación:</label>
                            <div class="input-group date" data-provide="datepicker">
                          <input type="date" class="form-control" name="fecha_observacion"  id="fecha_observacion" value="<?php echo $fecha_observacion; ?>" >
                            <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                              </div>
                            </div>

                                <script type="text/javascript">
                                     $(function(){
                                            $("#fecha_observacion").datepicker({ dateFormat: 'yy-mm-dd' });
                                            $("#from").datepicker({ dateFormat: 'yy-mm-dd' }).bind("change",function(){
                                                var minValue = $(this).val();
                                                minValue = $.datepicker.parseDate("yy-mm-dd", minValue);
                                                minValue.setDate(minValue.getDate()+1);
                                                $("#fecha_observacion").datepicker( "option", "minDate", minValue );
                                            })
                                        });
                                </script>

                        <div class="form-group">                       
                               <label for="nota_observacion">Nota de observación</label>
                               <select name="nota_observacion" id="nota_observacion" class="form-control" value="<?php echo $nota_observacion; ?>">
                        
                                <option value="1" <?php
                              if ($nota_observacion == 1) {
                                echo "selected";
                              }
                              ?>>nota 1</option>
                               <option value="2" <?php
                              if ($nota_observacion == 2) {
                                echo "selected";
                              }
                              ?>>nota 2</option>
                               <option value="3" <?php
                              if ($nota_observacion == 3) {
                                echo "selected";
                              }
                              ?>>nota 3</option>
                                   <option value="4" <?php
                              if ($nota_observacion == 4) {
                                echo "selected";
                              }
                              ?>>nota 4</option>
                               <option value="5" <?php
                              if ($nota_observacion == 5) {
                                echo "selected";
                              }
                              ?>>nota 5</option>
                               <option value="6" <?php
                              if ($nota_observacion == 6) {
                                echo "selected";
                              }
                              ?>>nota 6</option>
                               <option value="7" <?php
                              if ($nota_observacion == 7) {
                                echo "selected";
                              }
                              ?>>nota 7</option>



                               </select>
                        </div>            

                      
                                   </br>
                        <button type="submit" class="btn btn-primary" style="background-color: #006110;"><i class="fas fa-user-edit"></i> Editar Animal</button>
                        <a href="ver_observaciones.php?id_animal=<?php echo $data['id_animal']; ?>" class="btn btn-danger" ></i> atras</a>
                    </form>
                </div>
            </div>
        </div>
    </div>


</div>
<!-- /.container-fluid -->

<?php include_once "includes/footer.php"; ?>
