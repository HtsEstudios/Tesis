<?php
require("../conexion.php");
 include_once "js/tiempo_alert.js";
$id_user = $_SESSION['idUser'];
$permiso = "rubros";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d 
	ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");

if (!empty($_GET['id_rubro'])) {
    require("../conexion.php");
    $id_rubro = $_GET['id_rubro'];
    $query_delete = mysqli_query($conexion, "DELETE FROM rubro WHERE id_rubro = $id_rubro");
    mysqli_close($conexion);
    header("location: rubros.php");
}
?>