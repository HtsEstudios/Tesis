<script>
const cx = document.getElementById('f_fallecimiento');
let fechassss = <?php echo json_encode($totalfechassss); ?>;
let obserrrr = <?php echo json_encode($obssss); ?>;
const myCharttttt = new Chart(cx, {
    type: 'bar',
    data: {
        labels: fechassss,
        datasets: [{
            label: 'INGRESO TOTAL POR FECHA DE FALLECIMIENTO',
            data: obserrrr,
            backgroundColor: [
                'rgba(0, 255, 0, 0.2)'
                
            ],
            borderColor: [
                'rgba(0, 255, 0, 1)'
               
            ],
            borderWidth: 1,

           
        }]

    },
options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }      
 
    
});


</script>
