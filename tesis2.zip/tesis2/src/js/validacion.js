 <script type="text/javascript">
            
                         diio.oninput = function () {
                                        if (this.value.length > 9) {
                                            this.value = this.value.slice(0,9); 
                                        
                                        }
                                    }

                         altura.oninput = function () {
                                        if (this.value.length > 4) {
                                            this.value = this.value.slice(0,4); 
                                        
                                        }
                                    }

                         edad.oninput = function () {
                                        if (this.value.length > 4) {
                                            this.value = this.value.slice(0,4); 
                                        
                                        }
                                    }

                         peso.oninput = function () {
                                        if (this.value.length > 3) {
                                            this.value = this.value.slice(0,3); 
                                        
                                        }
                                    }

                      


                         numero.oninput = function () {
                                        if (this.value.length > 6) {
                                            this.value = this.value.slice(0,6); 
                                        
                                        }
                                    }
                        

                        

                          run.oninput = function () {
                                        if (this.value.length > 9) {
                                            this.value = this.value.slice(0,9); 
                                        
                                        }
                                    }

                         rup.oninput = function () {
                                        if (this.value.length > 9) {
                                            this.value = this.value.slice(0,9); 
                                        
                                        }
                                    }

                          telefono.oninput = function () {
                                        if (this.value.length > 9) {
                                            this.value = this.value.slice(0,9); 
                                        
                                        }
                                    }

                           celular.oninput = function () {
                                        if (this.value.length > 9) {
                                            this.value = this.value.slice(0,9); 
                                        
                                        }
                                    }

                         fax.oninput = function () {
                                        if (this.value.length > 9) {
                                            this.value = this.value.slice(0,9); 
                                        
                                        }
                                    }
                                    
                         coordenada_x.oninput = function () {
                                        if (this.value.length > 10) {
                                            this.value = this.value.slice(0,10); 
                                        
                                        }
                                    }

                         coordenada_y.oninput = function () {
                                        if (this.value.length > 10) {
                                            this.value = this.value.slice(0,10); 
                                    
                                        }
                                    }


                                                
                        </script>