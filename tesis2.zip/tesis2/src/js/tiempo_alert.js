<script>
window.setTimeout(function() {
    $(".alert").fadeTo(300, 0).slideDown(600, function(){
        $(this).remove(); 
    });
   }, 3000); </script> 