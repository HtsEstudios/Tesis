                        telefono.oninput = function () {
                                        if (this.value.length > 9) {
                                            this.value = this.value.slice(0,9); 
                                        
                                        }
                                    }

                           celular.oninput = function () {
                                        if (this.value.length > 9) {
                                            this.value = this.value.slice(0,9); 
                                        
                                        }
                                    }

                         fax.oninput = function () {
                                        if (this.value.length > 9) {
                                            this.value = this.value.slice(0,9); 
                                        
                                        }
                                    }
                         coordenada_x.oninput = function () {
                                        if (this.value.length > 10) {
                                            this.value = this.value.slice(0,10); 
                                        
                                        }
                                    }

                         coordenada_y.oninput = function () {
                                        if (this.value.length > 10) {
                                            this.value = this.value.slice(0,10); 
                                    
                                        }
                                    }
                         hectarea.oninput = function () {
                                        if (this.value.length > 6) {
                                            this.value = this.value.slice(0,6); 
                                        
                                        }
                                    }