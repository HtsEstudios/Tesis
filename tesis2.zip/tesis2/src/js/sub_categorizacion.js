function change(categorizacion, sub_categorizacion){
    categorizacion = document.getElementById(categorizacion);
    sub_categorizacion = document.getElementById(sub_categorizacion);
    sub_categorizacion.value ="";
    sub_categorizacion.innerHTML = "";
    if(categorizacion.value == "1")
    {
    var optionArray = ["|","1|Infarto",
                          "2|Hemorragia masiva",
                          "3|Lengua azul",
                          "4|Salmonela",
                          "5|Tuberculosis",
                          "6|Peste bubónica",
                          "7|Viruela",
                          "8|Fiebre aftosa",
                          "9|Accidente mortal o con consecuencia",]; 
} 

else if(categorizacion.value == "2"){
  var optionArray = ["|","10|Problema broncopulmonar",
                              "11|Secreciones de sangrado",
                              "12|Problema de movimiento",
                              "13|Accidente evidente",
                              "14|Tétanos",];
                            }

else if(categorizacion.value == "3"){
  var optionArray = ["|","15|Cólicos",
                              "16|Cálculos",
                              "17|Anemia",
                              "18|Atrofia muscular",];
                            }                           
else if(categorizacion.value == "4"){
  var optionArray = ["|","19|Hongos epidurales",
                              "20|Hongos faciales",
                              "21|Gripe",
                              "22|Diarrea",
                              "23|Dermatitis",
                              "24|Accidente ",];
                            } 
else if(categorizacion.value == "5"){
  var optionArray = ["|","25|Sospecha de enfermedad",
                              "26|Análisis calidad de estatus",
                              "27|Otros",];
                            

                            };

   for(option = 0;option < optionArray.length; option++){
    var pair = optionArray[option].split("|");
    var newOption = document.createElement("option");
    newOption.value = pair[0];
    newOption.innerHTML = pair[1];
    sub_categorizacion.options.add(newOption);
  };    
}