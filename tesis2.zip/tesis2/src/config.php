<?php
include_once "includes/header.php";
require_once "../conexion.php";
 include_once "js/tiempo_alert.js";
$id_user = $_SESSION['idUser'];
$permiso = "titular";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: permisos.php");
}

if (!empty($_POST)){
    $alert = '';
    if (empty($_POST['run'])||empty($_POST['nombre'])|| empty($_POST['apellido']) || empty($_POST['genero'])  || empty($_POST['telefono'])|| empty($_POST['celular'])|| empty($_POST['fax']) || empty($_POST['etnia'])|| empty($_POST['email'])) {
        $alert = '<div class="alert alert-danger" role="alert">
            Todo los campos son obligatorios
        </div>';
    }else{
        
        $run = $_GET['run'];
        $nombre        = $_POST['nombre'];
        $apellido      = $_POST['apellido'];
        $genero        = $_POST['genero'];
        $telefono      = $_POST['telefono'];
        $celular       = $_POST['celular'];
        $fax           = $_POST['fax'];
        $etnia         = $_POST['etnia'];
        $usuario_indap = $_POST['usuario_indap'];
        $email         = $_POST['email'];
        


        $update = mysqli_query($conexion, "UPDATE titular SET nombre = '$nombre', apellido = '$apellido', genero = '$genero', telefono = '$telefono', celular  = '$celular',fax  = '$fax', etnia  = '$etnia', usuario_indap  = '$usuario_indap', email  = '$email' WHERE run = $run");
     
            $alert = '<div class="alert alert-success" role="alert">
            Datos modificado
        </div>';
        }
    }


 if (empty($_REQUEST['run'])) {
    header("Location: titular.php");
}
$run = $_REQUEST['run'];
$sql = mysqli_query($conexion, "SELECT * FROM titular WHERE run = $run");
$result_sql = mysqli_num_rows($sql);
if ($result_sql == 0) {
    header("Location: titular.php");
} else {
    if ($data = mysqli_fetch_array($sql)) {
        $run           = $data['run'];
        $nombre        = $data['nombre'];
        $apellido      = $data['apellido'];
        $genero        = $data['genero'];
        $telefono      = $data['telefono'];
        $celular       = $data['celular'];
        $fax           = $data['fax'];
        $etnia         = $data['etnia'];
        $usuario_indap = $data['usuario_indap'];
        $email         = $data['email'];
    }
}
?>

<div class="row">
<div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header text-white" style="background-color: #006110;">
                 <h4> Datos del Titular </h4>  
                </div>
                <div class="card-body">
                    <form action="" method="post" class="p-3">
                        <div class="form-group">
                            <?php echo isset($alert) ? $alert : ''; ?>
                            <label>Run:</label>
                            <input type="number" name="run" class="form-control" value="<?php echo $data['run']; ?>" id="run" readonly="readonly" placeholder=""  required>
                        </div> 

                        <div class="form-group">
                            <label>Nombre:</label>
                            <input type="text" name="nombre" class="form-control" value="<?php echo $data['nombre']; ?>" id="nombre" placeholder="Nombre " minlength="6"  maxlength="20" required>
                        </div>
                         <div class="form-group">
                            <label>Apellido:</label>
                            <input type="text" name="apellido" class="form-control" value="<?php echo $data['apellido']; ?>" id="apellido" placeholder="Apellido" minlength="6"  maxlength="20" required>
                        </div>
                          <div class="form-group">
                          <label for="genero">Género</label>
                          <select name="genero" id="genero" class="form-control" value="<?php echo $genero; ?>">
                           <option value="1" <?php  if($genero == 1) {
                                                echo "selected";
                                              }
                                              ?>>MASCULINO</option>

                            <option value="2" <?php    if($genero == 2) {
                                                echo "selected";
                                              }
                                              ?>>FEMENINO</option>
                           
                         
                        </select></div>
                        <div class="form-group">
                            <label>Teléfono:</label>
                            <input type="number" name="telefono" class="form-control" value="<?php echo $data['telefono']; ?>" id="telefono" placeholder="telefono" required>
                        </div>
                        <div class="form-group">
                            <label>Celular:</label>
                            <input type="number" name="celular" class="form-control" value="<?php echo $data['celular']; ?>" id="celular" placeholder="celular"   required>
                        </div>
                     
                        <div class="form-group">
                            <label>Fax:</label>
                            <input type="number" name="fax" class="form-control" value="<?php echo $data['fax']; ?>" id="fax" placeholder="fax"  required>
                        </div>
                       
                         <div class="form-group">
                          <label for="etnia">Etnia</label>
                          <select name="etnia" id="etnia" class="form-control" value="<?php echo $etnia; ?>">
                                <option value="1" <?php  if($etnia == 1) {
                                                echo "selected";
                                              }
                                              ?>>MAPUCHE</option>

                            <option value="2" <?php    if($etnia == 2) {
                                                echo "selected";
                                              }
                                              ?>>CHILENO</option>
                             <option value="3" <?php if($etnia == 3) {
                                                echo "selected";
                                              }
                                              ?>>OTRO</option>
                         
                        </select></div>





                       
                        <div class="form-group">
                            <label>Usuario indap:</label>
                            <input type="text" name="usuario_indap" class="form-control" value="<?php echo $data['usuario_indap']; ?>" id="usuario_indap" placeholder="usuario indap" minlength="6"  maxlength="9">
                        </div>
                         <div class="form-group">
                            <label>Email:</label>
                            <input type="email" name="email" class="form-control" value="<?php echo $data['email']; ?>" id="email" placeholder="Correo " minlength="6"  maxlength="30">
                        </div>
                        <?php echo isset($alert) ? $alert : ''; ?>
                        <div>
                            <button type="submit" class="btn btn-primary" style="background-color: #006110;"><i class="fas fa-save"></i> Modificar Datos</button>
                             <a href="titular.php" class="btn btn-danger">Atras</a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
</div>
     <script src="js\validacion3.js" type="text/javascript"></script>
  <script src="js\validacion2.js" type="text/javascript"></script>
    <?php     include "js/validacion.js";  ?>
<?php include_once "includes/footer.php"; ?>