<?php include_once "includes/header.php";
include "../conexion.php";
 include_once "js/tiempo_alert.js";
$id_user = $_SESSION['idUser'];
$permiso = "animal";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
if (!empty($_POST)){
    $alert = "";
    if (empty($_POST['edad']) || empty($_POST['sexo']) || empty($_POST['peso']) || empty($_POST['altura'])  || empty($_POST['diio']) || empty($_POST['id_establecimiento']) || empty($_POST['id_raza']) || empty($_POST['fecha_nacimiento'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        Todo los campos son obligatorios
        </div>';
    } else {
        $id_animal = $_GET['id_animal'];
        $edad                  = $_POST['edad'];
        $sexo                  = $_POST['sexo'];
        $peso                  = $_POST['peso'];
        $altura                = $_POST['altura'];
        $diio                  = $_POST['diio'];
        $id_establecimiento    = $_POST['id_establecimiento'];
        $id_raza               = $_POST['id_raza'];
        $fecha_nacimiento      = $_POST['fecha_nacimiento'];
        $fecha_muerte          = $_POST['fecha_muerte'];
       
        $sql_update = mysqli_query($conexion, "UPDATE animal SET edad = '$edad', sexo = '$sexo', peso = '$peso', altura = '$altura', diio = '$diio', id_establecimiento = '$id_establecimiento', id_raza = '$id_raza',fecha_nacimiento = '$fecha_nacimiento',fecha_muerte = '$fecha_muerte' WHERE id_animal = $id_animal");

        $alert = '<div class="alert alert-success" role="alert">edicion Actualizado</div>';
    }
}

// Mostrar Datos

if (empty($_REQUEST['id_animal'])) {
    header("Location: animal.php");
}
$id_animal = $_REQUEST['id_animal'];
$sql = mysqli_query($conexion, "SELECT * FROM animal WHERE id_animal = $id_animal");
$result_sql = mysqli_num_rows($sql);
if ($result_sql == 0) {
    header("Location: animal.php");
} else {
    if ($data = mysqli_fetch_array($sql)) {
        $id_animal             = $data['id_animal'];
        $edad                  = $data['edad'];
        $sexo                  = $data['sexo'];
        $peso                  = $data['peso'];
        $altura                = $data['altura'];
        $diio                  = $data['diio'];
        $id_establecimiento    = $data['id_establecimiento'];
        $id_raza               = $data['id_raza'];
        $fecha_nacimiento      = $data['fecha_nacimiento'];
        $fecha_muerte          = $data['fecha_muerte'];
    }
}
?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-6 m-auto">
            <div class="card">
                <div class="card-header  text-white" style="background-color: #006110;">
                    Modificar Animal
                </div>
                <div class="card-body">
                    <form class="" action="" method="post">
                        <?php echo isset($alert) ? $alert : ''; ?>
                        <input type="hidden" name="id_animal" id="" value="<?php echo $id_animal; ?>">
            
                        <div class="form-group">
                            <label>DIIO:</label>
                            <input type="number" name="diio" class="form-control"  id="diio" placeholder="Ingrese el DIIO del ejemplar. " value="<?php echo $diio; ?>"  readonly="readonly" required>
                        </div>

                       <div class="form-group">
                        <label for="edad">Edad:</label>
                        <input type="number" step="0.01" class="form-control" placeholder="Ingrese la Edad del ejemplar" name="edad" id="edad" value="<?php echo $edad; ?>" required>
                    </div>
                    

                        <div class="form-group">
                          <label for="sexo">sexo</label>
                          <select name="sexo" id="sexo" class="form-control" value="<?php echo $sexo; ?>">
                            <option value="1" <?php  if ($sexo == 1) {
                                                echo "selected";
                                              }
                                              ?>>macho</option>

                            <option value="2" <?php    if ($sexo == 2) {
                                                echo "selected";
                                              }
                                              ?>>hembra</option>

                          </select>
                        </div>



                         <div class="form-group">
                            <label>Peso:</label>
                            <input type="number" step="0.01" name="peso" class="form-control" id="peso" placeholder="Ingrese el Peso del ejemplar. " value="<?php echo $peso; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Altura:</label>
                            <input type="number" step="0.01" name="altura" class="form-control" id="altura" placeholder="Ingrese la Altura del ejemplar. " value="<?php echo $altura; ?>"    required>
                        </div>
                        

                        <div class="form-group">
                            <label for="">ID del establecimiento</label>
                            <select name="id_establecimiento" id="id_establecimiento" class="form-control" value="<?php echo $id_establecimiento; ?>">
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from establecimiento");
                        //mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($id_establecimiento2 = mysqli_fetch_array($query_rol)) {
                        ?>
                

                                <option value="<?php echo $id_establecimiento2["id_establecimiento"]; ?>"<?=$id_establecimiento2['id_establecimiento'] == $id_establecimiento ? ' selected="selected"' : '';?>  ><?php echo $id_establecimiento2["nombre_establecimiento"] ?></option>
                        <?php
                            }
                        }
                        ?>
                        </select></div>   

                        <div class="form-group">
                            <label for="">ID Raza</label>
                            <select name="id_raza" id="id_raza" class="form-control" value="<?php echo $id_raza; ?>">
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from raza");
                        mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($id_raza2 = mysqli_fetch_array($query_rol)) {
                        ?>
                                <option value="<?php echo $id_raza2["id_raza"]; ?>"<?=$id_raza2['id_raza'] == $id_raza ? ' selected="selected"' : '';?> ><?php echo $id_raza2["especie_animal"] ?>&nbsp;<?php echo $id_raza2["subraza"] ?></option>
                        <?php
                            }
                        }
                        ?>
                        </select></div>

                       

                        <label for="fecha_nacimiento">Fecha de nacimiento:</label>
                        <div class="input-group date" data-provide="datepicker">
                          <input type="date" class="form-control" name="fecha_nacimiento"  id="fecha_nacimiento" value="<?php echo $fecha_nacimiento; ?>">
                         <div class="input-group-addon">
                        <span class="glyphicon glyphicon-th"></span>
                              </div>
                            </div>

                                <script type="text/javascript">
                                     $(function(){
                                            $("#fecha_nacimiento").datepicker({ dateFormat: 'yy-mm-dd' });
                                            $("#from").datepicker({ dateFormat: 'yy-mm-dd' }).bind("change",function(){
                                                var minValue = $(this).val();
                                                minValue = $.datepicker.parseDate("yy-mm-dd", minValue);
                                                minValue.setDate(minValue.getDate()+1);
                                                $("#fecha_nacimiento").datepicker( "option", "minDate", minValue );
                                            })
                                        });
                                </script>

                       </br>
                       <label for="fecha_nacimiento">Fecha de Muerte:</label>
                        <div class="input-group date" data-provide="datepicker">
                          <input type="date" class="form-control" name="fecha_muerte"  id="fecha_muerte" value="<?php echo $fecha_muerte; ?>">
                         <div class="input-group-addon">
                        <span class="glyphicon glyphicon-th"></span>
                              </div>
                            </div>

                                <script type="text/javascript">
                                     $(function(){
                                            $("#fecha_muerte").datepicker({ dateFormat: 'yy-mm-dd' });
                                            $("#from").datepicker({ dateFormat: 'yy-mm-dd' }).bind("change",function(){
                                                var minValue = $(this).val();
                                                minValue = $.datepicker.parseDate("yy-mm-dd", minValue);
                                                minValue.setDate(minValue.getDate()+1);
                                                $("#fecha_muerte").datepicker( "option", "minDate", minValue );
                                            })
                                        });
                                </script>

                            </br>
                        <button type="submit" class="btn btn-primary" style="background-color: #006110;"><i class="fas fa-user-edit"></i> Editar Animal</button>
                        <a href="animal.php" class="btn btn-danger">Atras</a>
                    </form>
                </div>
            </div>
        </div>
    </div>


</div>
<!-- /.container-fluid -->
    <?php     include "js/validacion.js";  ?>
<?php include_once "includes/footer.php"; ?>