$query = mysqli_query($conexion,"INSERT INTO fecha_ingreso (fecha, idusuario) values ($date, $idUser)"); 
 $date = date('m/d/Y h:i:s', time());


select DISTINCT(fecha_nacimiento) FROM animal;
 SELECT COUNT(id_animal) FROM `animal` WHERE fecha_nacimiento ='2021-11-16';