<?php
require("../conexion.php");
 include_once "js/tiempo_alert.js";
$id_user = $_SESSION['idUser'];
$permiso = "titular";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d 
	ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");

if (!empty($_GET['run'])) {
    require("../conexion.php");
    $run = $_GET['run'];
    $query_delete = mysqli_query($conexion, "DELETE FROM titular WHERE run = $run");
    mysqli_close($conexion);
    header("location: titular.php");
}
?>