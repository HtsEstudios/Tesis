<?php include_once "includes/header.php";
 include_once "js/tiempo_alert.js";
date_default_timezone_set('America/Santiago');
include "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "establecimiento";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
if (!empty($_POST)) {
    $alert = "";
    if (empty($_POST['rup'])|| empty($_POST['coordenada_x']) || empty($_POST['coordenada_y'])  || empty($_POST['oficina_sag'])|| empty($_POST['tipo_ubicacion'])|| empty($_POST['tipo_establecimiento']) || empty($_POST['sucesion']) || empty($_POST['nombre_establecimiento']) || empty($_POST['hectarea']) || empty($_POST['criterio_de_riesgo'])|| empty($_POST['direccion_id'])|| empty($_POST['run'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        Todo los campos son obligatorios
        </div>';
    } else {
       
        $rup                          = $_POST['rup'];
        $coordenada_x                 = $_POST['coordenada_x'];
        $coordenada_y                 = $_POST['coordenada_y'];
        $oficina_sag                  = $_POST['oficina_sag'];
        $tipo_ubicacion               = $_POST['tipo_ubicacion'];
        $tipo_establecimiento         = $_POST['tipo_establecimiento'];
        $sucesion                     = $_POST['sucesion'];
        $nombre_establecimiento       = $_POST['nombre_establecimiento'];
        $hectarea                     = $_POST['hectarea'];
        $criterio_de_riesgo           = $_POST['criterio_de_riesgo'];
        $direccion_id                 = $_POST['direccion_id'];
        $run                          = $_POST['run'];
        $date = date('Y-m-d');
        $id_rubro                     = $_POST['id_rubro'];

        $query = mysqli_query($conexion, "SELECT * FROM establecimiento where rup = '$rup'");

        $result = mysqli_fetch_array($query);
        if ($result > 0) {
            $alert = '<div class="alert alert-warning" role="alert">
                        El establecimiento ya existe
                    </div>';
        } else {
            $query_insert = mysqli_query($conexion, "INSERT INTO establecimiento(rup,coordenada_x,coordenada_y,oficina_sag,tipo_ubicacion,tipo_establecimiento,sucesion,nombre_establecimiento,hectarea,criterio_de_riesgo,direccion_id,run,fecha_ingreso,id_rubro) values ('$rup', '$coordenada_x', '$coordenada_y', '$oficina_sag', '$tipo_ubicacion', '$tipo_establecimiento', '$sucesion', '$nombre_establecimiento', '$hectarea',  '$criterio_de_riesgo', '$direccion_id', '$run', '$date', '$id_rubro')");
          
            if ($query_insert) {
                $alert = '<div class="alert alert-primary" role="alert">
                            Establecimiento registrado
                        </div>';
            } else {
                $alert = '<div class="alert alert-danger" role="alert">
                        Error al registrar
                    </div>';
            }
        }
    }
}
?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray">Panel de Establecimiento </h1>  <?php echo isset($alert) ? $alert : ''; ?>
    </div>
<div>
<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#nuevo_establecimiento" style="background-color: #006110;"><i class="fas fa-plus"></i></button>

<a href="direccion.php"><button class="btn" type="button" style="background-color: #EAFE15;" >direcciones</button></a>
</div></br>

<div id="nuevo_establecimiento" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header  text-white" style="background-color: #006110;">
                <h5 class="modal-title" id="my-modal-title" >Nuevo Establecimiento</h5>
         <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="post" autocomplete="off">
                    <?php echo isset($alert) ? $alert : ''; ?>

                    <div class="form-group">
                        <label >rup: </label>
                        <input type="number"name="rup" id="rup" class="form-control" placeholder="Ingrese rup"  required>
                    </div>
                  
                    <div class="form-group">
                        <label for="coordenada_x">Coordenada GPS X: </label>
                        <input type="number" step="0.00001" class="form-control" placeholder="Ingrese coordenada_x" name="coordenada_x" id="coordenada_x"  required>
                    </div>
                         <div class="form-group">
                            <label>Coordenada GPS y:</label>
                            <input type="number" step="0.00001" name="coordenada_y" class="form-control" id="coordenada_y" placeholder="Ingrese coordenada_y" required>
                        </div>
                         <script type="text/javascript">
                      coordenada_x.oninput = function () {
                                        if (this.value.length > 10) {
                                            this.value = this.value.slice(0,10); 
                                        
                                        }
                                    }

                         coordenada_y.oninput = function () {
                                        if (this.value.length > 10) {
                                            this.value = this.value.slice(0,10); 
                                    
                                        }
                                    }
                                          </script>
                
                         <div class="form-group">
                            <label>Oficina sag:</label>
                            <input type="text" name="oficina_sag" class="form-control" id="oficina_sag" placeholder="oficina que corresponde tu establecimiento "  minlength="4"  maxlength="20" required >
                        </div>
                       
                         <div class="form-group">
                          <label for="tipo_ubicacion">Tipo ubicación</label>
                          <select name="tipo_ubicacion" id="tipo_ubicacion" class="form-control" value="<?php echo $tipo_ubicacion; ?>">
                            <option value="">------seleccione un tipo ubicación------</option>
                            <option value="1" >absoluta</option>
                            <option value="2">relativa</option>

                              </select>
                        </div>

                         <div class="form-group">
                          <label for="tipo_establecimiento">Tipo establecimiento</label>
                          <select name="tipo_establecimiento" id="tipo_establecimiento" class="form-control" value="<?php echo $tipo_establecimiento; ?>">
                             <option value="">------seleccione un tipo establecimiento------</option>
                            <option value="1" >PREDIO</option>
                            <option value="2">MATADERO</option>
                            <option value="3" >CFA</option>
                            <option value="4">RECINTO FERIAL</option>
                            <option value="5" >TRASPATIO</option>

                              </select>
                        </div>

                        <div class="form-group">
                            <label>Sucesión:</label>
                            <input type="text" name="sucesion" class="form-control"  id="sucesion" placeholder="elija sucesion o coloque --no-- " minlength="2"  maxlength="20" required>
                        </div>
                        <div class="form-group">
                            <label>Nombre establecimiento:</label>
                            <input type="text" name="nombre_establecimiento" class="form-control"  id="nombre_establecimiento" placeholder="nombre_establecimiento "  minlength="4"  maxlength="20" required>
                        </div>
                     
                        <div class="form-group">
                            <label>Hectárea:</label>
                            <input type="number" name="hectarea" class="form-control" id="hectarea" placeholder=" Cantidad de hectarea sin punto"  required>
                        </div>
                        <script type="text/javascript">
                            hectarea.oninput = function () {
                                        if (this.value.length > 6) {
                                            this.value = this.value.slice(0,6); 
                                    
                                        }
                                    }

                        </script>

                          <div class="form-group">
                          <label for="criterio_de_riesgo">Criterio de riesgo</label>
                          <select name="criterio_de_riesgo" id="criterio_de_riesgo" class="form-control" value="<?php echo $criterio_de_riesgo; ?>">
                            <option value="">------seleccione un criterio de riesgo------</option>
                            <option value="1" >CAMPO DE PASTOREO CORDILLERANO LIMÍTROFE</option>
                            <option value="2">CAMPO DE PASTOREO CORDILLERANO NO LIMÍTROFE</option>
                            <option value="3" >UNIDAD EPIDEMIOLÓGICA</option>
                            <option value="4">HUMEDALES</option>
                            <option value="5" >CUARENTENA DE INTERNACIÓN</option>
                            <option value="6" >BIOTERIO</option>
                            <option value="7">CAMPO LIMÍTROFE</option>
                            <option value="8" >SIN CRITERIO DE RIESGO</option>
                              </select>
                        </div>
                        <div class="form-group">
                    <label>Dirección</label>
                    <select name="direccion_id" id="direccion_id" class="form-control" required>
                        <option value="">------seleccione una dirección------</option>
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from direccion_establecimiento");
                        //mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($direccion_id = mysqli_fetch_array($query_rol)) {
                        ?>
                                <option value="<?php echo $direccion_id["direccion_id"]; ?>"><?php echo $direccion_id["direccion"] ?>&nbsp;<?php echo $direccion_id["numero"] ?></option>
                        <?php

                            }
                        }

                        ?>
                    </select></div>
                        <div class="form-group">
                    <label>Run titular</label>
                    <select name="run" id="run" class="form-control" required>
                         <option value="">------seleccione un titular------</option>
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from titular");
                   //    mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($run = mysqli_fetch_array($query_rol)) {
                        ?>
                                <option value="<?php echo $run["run"]; ?>"><?php echo $run["run"] ?></option>
                        <?php

                            }
                        }

                        ?>
                    </select></div> 

                        <div class="form-group">
                    <label>Rubro</label>
                    <select name="id_rubro" id="id_rubro" class="form-control" required>
                        <option value="">------seleccione un Rubro------</option>
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from rubro");
                       mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($id_rubro = mysqli_fetch_array($query_rol)) {
                        ?>
                                <option value="<?php echo $id_rubro["id_rubro"]; ?>"><?php echo $id_rubro["nombre_rubro"] ?></option>
                        <?php

                            }
                        }

                        ?>
                    </select></div>    
                    <input type="submit" value="Registrar" class="btn btn-primary" style="background-color: #006110;">
                </form>
            </div>
        </div>
    </div>
</div>
        <div class="col-lg-12">
            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered mt-2" id="tbl">
                    <thead class="thead-dark">
                        <tr>
                            <th>RUP</th>
                            <th>NOMBRE ESTABLECIMIENTO</th>
                            <th>DIRECCIÓN</th>
                            <th>OFICINA SAG</th>
                            <th>TIPO DE UBICACION</th>
                            <th>TIPO DE ESTABLECIMIENTO</th> 
                            <th>CRITERIO DE RIESGO</th> 
                            <th>HECTÁREA</th>
                            <th>RUBRO</th>
                            <th>FECHA INGRESO</th>
                            <th></th>     
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include "../conexion.php";

                        $query = mysqli_query($conexion, "SELECT e.id_establecimiento, e.rup, e.coordenada_x, e.coordenada_y, e.oficina_sag, 
                            e.tipo_ubicacion, e.tipo_establecimiento,e.sucesion,e.nombre_establecimiento,e.hectarea,e.criterio_de_riesgo,d.direccion_id,
                            d.direccion,d.numero,e.run,e.fecha_ingreso,e.id_rubro, r.id_rubro, r.nombre_rubro FROM  establecimiento e INNER JOIN direccion_establecimiento d ON e.direccion_id = d.direccion_id  INNER JOIN rubro r ON e.id_rubro = r.id_rubro");

                        $result = mysqli_num_rows($query);
                        if ($result > 0) {
                            while ($data = mysqli_fetch_assoc($query)) { ?>
                                <tr>
                                    <td><?php echo $data['rup']; ?></td>
                                    <td><?php echo $data['nombre_establecimiento']; ?></td>
                                    <td><?php echo $data['direccion']; ?>&nbsp;<?php echo $data['numero']; ?></td>    
                                    <td><?php echo $data['oficina_sag']; ?></td>
                                    <td><?php  if ($data['tipo_ubicacion'] == 1) {echo "absoluta"; } 
                                    else{echo "relativa"; }?>
                                    </td>
                                    <td><?php  
                                    if ($data['tipo_establecimiento'] == 1) {
                                        echo "PREDIO"; 
                                         } 
                                    elseif ( $data['tipo_establecimiento']==2) {
                                          echo "MATADERO"; 
                                    }
                                    elseif ( $data['tipo_establecimiento']==3) {
                                          echo "CFA"; 
                                    }
                                    elseif ( $data['tipo_establecimiento']==4) {
                                          echo "RECINTO FERIAL"; 
                                    }
                                    elseif ( $data['tipo_establecimiento']==5) {
                                          echo "TRASPATIO"; 
                                    }
                                    ?>

                                    <td><?php  
                                    if ($data['criterio_de_riesgo'] == 1) {
                                        echo "CAMPO DE PASTOREO CORDILLERANO LIMÍTROFE"; 
                                         } 
                                    elseif ( $data['criterio_de_riesgo']==2) {
                                          echo "CAMPO DE PASTOREO CORDILLERANO NO LIMÍTROFE"; 
                                    }
                                    elseif ( $data['criterio_de_riesgo']==3) {
                                          echo "UNIDAD EPIDEMIOLÓGICA"; 
                                    }
                                    elseif ( $data['criterio_de_riesgo']==4) {
                                          echo "HUMEDALES"; 
                                    }
                                    elseif ( $data['criterio_de_riesgo']==5) {
                                          echo "CUARENTENA DE INTERNACIÓN"; 
                                    }
                                    elseif ( $data['criterio_de_riesgo']==6) {
                                          echo "BIOTERIO"; 
                                    }
                                    elseif ( $data['criterio_de_riesgo']==7) {
                                          echo "CAMPO LIMÍTROFE"; 
                                    }
                                    elseif ( $data['criterio_de_riesgo']==8) {
                                          echo "SIN CRITERIO DE RIESGO"; 
                                    }
                                    ?>
                                    </td>
                                    </td>

                                    <td><?php echo $data['hectarea']; ?>&nbsp;hectárea</td>
                                    <td><?php echo $data['nombre_rubro']; ?></td>
                                    <td><?php echo $data['fecha_ingreso']; ?></td>

                                    
                                    
                                   <td>

                                        <a href="config.php?run=<?php echo $data['run']; ?>" class="btn btn-success" style="background-color: #ffb900;"><i class='fas fa-edit'></i> ver titular</a>
                                    </br>
                                        <a href="editar_establecimiento.php?id_establecimiento=<?php echo $data['id_establecimiento']; ?>" class="btn btn-success" style="background-color: #006110;"><i class='fas fa-edit'></i> Editar</a>
                                    </td>
                                   
                                    <?php } ?>
                                </tr>

                        <?php }
                        ?>
                    </tbody>

                </table>
            </div>

    </div>

<script src="js\validacion3.js" type="text/javascript"></script>
<script src="js\validacion2.js" type="text/javascript"></script>
    <?php     include "js/validacion.js";  ?>
<?php include_once "includes/footer.php"; ?>