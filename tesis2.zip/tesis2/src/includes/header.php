<?php
session_start();
if (empty($_SESSION['active'])) {
    header('location: ../');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title> Happy Animals</title>
    <link rel="shortcut icon" href="img/logo3.ico" />
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <link href="../assets/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <link rel="stylesheet" href="../assets/js/jquery-ui/jquery-ui.min.css">
    <script src="../assets/js/all.min.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed" >
    <nav class="sb-topnav navbar navbar-expand " style="background-color: #006110;">
     <a class="navbar-bran" href="index.php"  style="color: white;">
       <img src="img/logo2.png" class="img-transparent-thumbnail" style=" width: 100px; height: 70px;">
       Happy Animals 
   <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#" style="color: white;"><i class="fas fa-bars"></i></button>
        </a> 

        <!-- Navbar-->
        <ul class="navbar-nav ml-auto" >
            <li class="nav-item dropdown" >
                <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown" style="color: white;" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-user fa-fw" style="color: white;" ></i></a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#nuevo_pass">cambiar contraseña</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="salir.php">Cerrar Sessión</a>
                </div>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav"  >
        <div id="layoutSidenav_nav" >
            <nav class="sb-sidenav accordion" id="sidenavAccordion" style="background-color: #004712;" >
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        
                         <a class="nav-link" href="usuarios.php" style="color: white;">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            Usuarios
                        </a>
                         <a class="nav-link" href="animal.php" style="color: white;">
                            <div class="sb-nav-link-icon"></div>
                            Ejemplares
                        </a>

                        <a class="nav-link" href="titular.php" style="color: white;">
                            <div class="sb-nav-link-icon"></div>
                            Titular
                        </a>

                         <a class="nav-link" href="establecimiento.php" style="color: white;">
                            <div class="sb-nav-link-icon"></div>
                            Establecimiento
                        </a>
                        
                        <a class="nav-link" href="rubros.php" style="color: white;">
                            <div class="sb-nav-link-icon"></div>
                            Rubros
                        </a>
                       
                        <a class="nav-link" href="fechas.php" style="color: white;">
                            <div class="sb-nav-link-icon"></div>
                            Historial
                        </a>
                      
                        
                       
                    </div>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid mt-2">