
<?php include_once "includes/header.php";
 include_once "js/tiempo_alert.js";

date_default_timezone_set('America/Santiago');
include "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "ejemplares";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
if (!empty($_POST)){
    $alert = "";
    if (empty($_POST['sexo']) || empty($_POST['peso']) || empty($_POST['altura'])  || empty($_POST['diio']) || empty($_POST['id_establecimiento']) || empty($_POST['id_raza'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        Todo los campos son obligatorios
        </div>';
    } else {
        $edad                  = $_POST['edad'];
        $sexo                  = $_POST['sexo'];
        $peso                  = $_POST['peso'];
        $altura                = $_POST['altura'];
        $diio                  = $_POST['diio'];
        $id_establecimiento    = $_POST['id_establecimiento'];
        $id_raza               = $_POST['id_raza'];
        $fecha_nacimiento      = $_POST['fecha_nacimiento'];
        $fecha_muerte          = $_POST['fecha_muerte'];
       
        $date = date('Y-m-d H:i:s');



        $query = mysqli_query($conexion, "SELECT * FROM animal where diio = '$diio'");

        $result = mysqli_fetch_array($query);
        if ($result > 0) {
            $alert = '<div class="alert alert-warning" role="alert">
                        El diio ya existe
                    </div>';
        } else {
            $query_insert = mysqli_query($conexion, "INSERT INTO animal(edad,sexo,peso,altura,diio,id_establecimiento,id_raza,fecha_nacimiento,fecha_muerte,fecha_ingreso) values ('$edad', '$sexo', '$peso', '$altura', '$diio', '$id_establecimiento', '$id_raza', '$fecha_nacimiento',  '$fecha_muerte', '$date')");
            if ($query_insert) {
                $alert = '<div class="alert alert-primary" role="alert">
                            Ejemplar registrado
                        </div>';
            } else {
                $alert = '<div class="alert alert-danger" role="alert">
                        Error al registrar ejemplar
                    </div>';
            }
        }
    }
}
?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <script src="librerias/jquery-3.3.1.min.js"></script>
    <script src="librerias/jquery-ui-1.12.1.custom/jquery-ui.js"></script>

        <h1 class="h3 mb-0 text-gray">Panel del Ejemplar </h1>  <?php echo isset($alert) ? $alert : ''; ?>
    </div>
    <div>
<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#nuevo_animal" style="background-color: #006110;"><i class="fas fa-plus"></i></button>

<a href="observacion.php"><button class="btn" type="button" style="background-color: #EAFE15;" >Observaciones</button></a>
<a href="graficos.php"><button class="btn" type="button" style="background-color: #73FF00;" >graficos</button></a>
</div>
</br>
<div id="nuevo_animal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header  text-white" style="background-color: #006110;">
                <h5 class="modal-title" id="my-modal-title" >Nuevo Animal</h5>
         <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="post" autocomplete="off">
                    <?php echo isset($alert) ? $alert : ''; ?>

                     <div class="form-group">
                            <label>DIIO:</label>
                            <input type="number" name="diio" class="form-control"  id="diio" placeholder="Ingrese el DIIO del ejemplar. "  required>
                        </div>

                      <label for="sexo">Sexo:</label>
                     <div class="form-check">

                          <input class="form-check-input" type="radio" value="1" name="sexo" id="sexo">
                          <label class="form-check-label" for="flexRadioDefault1">
                            Macho
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" value="2" name="sexo" id="sexo">
                          <label class="form-check-label" for="flexRadioDefault2">
                            Hembra
                          </label>
                        </div>



                         <div class="form-group">
                            <label>Peso:</label>
                            <input type="number" step="0.01" name="peso" class="form-control" id="peso" placeholder="Ingrese el peso del ejemplar. " required>
                        </div>
                          
                        <div class="form-group">
                            <label>Altura:</label>
                            <input type="number" step="0.01" name="altura" class="form-control" id="altura" placeholder="Ingrese la altura del ejemplar en MTS. " required>
                        </div>

                         
                        <div class="form-group">
                            <label for="">ID del establecimiento</label>
                            <select name="id_establecimiento" id="id_establecimiento" placeholder="Elija el establecimiento" class="form-control">
                                 <option value="">------seleccione un establecimiento------</option>
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from establecimiento");
                        //mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($id_establecimiento = mysqli_fetch_array($query_rol)) {
                        ?>
                              
                                <option value="<?php echo $id_establecimiento["id_establecimiento"]; ?>"><?php echo $id_establecimiento["nombre_establecimiento"] ?></option>
                        <?php
                            }
                        }
                        ?>
                        </select></div>   

                        <div class="form-group">
                            <label for="">ID Raza</label>
                            <select name="id_raza" id="id_raza" class="form-control" placeholder="Elija la raza del animal">
                                <option value="">------seleccione una raza------</option>
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from raza ORDER BY especie_animal ");
                        mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($id_raza = mysqli_fetch_array($query_rol)) {
                        ?>
                                
                                <option value="<?php echo $id_raza["id_raza"]; ?>"><?php echo $id_raza["especie_animal"] ?>&nbsp;<?php echo $id_raza["subraza"] ?></option>
                        <?php
                            }
                        }
                        ?>
                        </select></div>
     
                <div class="form-group">
                <label>Escribe tu fecha de nacimiento</label>
                <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" class="form-control input-es tuiker" placeholder="Elija la fecha de nacimiento del ejemplar" readonly="">

                </div>
                <div class="form-group">
                <label>Edad</label>
                 <input  id="edad" name="edad" class="form-control input" readonly="">
                
           

            </div>

   <script type="text/javascript">




    $(document).ready(function(){
        $("#fecha_nacimiento").datepicker({
            changeMonth: true,
            changeYear: true,
            yearRange: '1990:',
            dateFormat: "yy-mm-dd",
            firstDay:1,
            monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
            dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
            dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
            dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá']
        });

        $('#fecha_nacimiento').change(function(){
            $.ajax({

                type:"POST",
                data:"fecha=" + $('#fecha_nacimiento').val(),
                url:"calcularEdad.php",
                success:function(r){
                     let caja = $("#edad")
                    caja.val(r)
                }
            });
        });
    });


</script>

                        <div class="form-group">
                            <label for="fecha_muerte">Fecha de fallecimiento:</label>
                            <input type="text" name="fecha_muerte" class="form-control" id="fecha_muerte" readonly="readonly">
                        </div>                         
                    <input type="submit" value="Registrar" class="btn btn-primary" style="background-color: #006110;">
                </form>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered mt-2" id="tbl">
                    <thead class="thead-dark">
                        <tr>
                            <th>DIIO</th>
                            <th>EDAD</th>
                            <th>SEXO</th>
                            <th>PESO</th>
                            <th>ALTURA</th>
                            <th>ESPECIE ANIMAL</th>
                            <th>SUB RAZA</th>
                            <th>FECHA NACIMIENTO</th>
                            <th>ESTADO</th>
                            <th>FECHA INGRESO</th>
                            <th></th>     
                        </tr>
                    </thead>
                    <style>
    #heading { color: #006110; }
    #heading2 { color: #FF0000; }
  </style>
                    <tbody>
                        <?php
                        include "../conexion.php";

                        $query = mysqli_query($conexion, "SELECT a.id_animal, a.edad, a.sexo, a.peso, a.altura, a.diio, a.fecha_nacimiento, a.fecha_muerte,
                         a.fecha_ingreso, r.especie_animal, r.subraza FROM  animal a INNER JOIN raza r ON a.id_raza = r.id_raza");
                        $result = mysqli_num_rows($query);
                        if ($result > 0) {
                            while ($data = mysqli_fetch_assoc($query)) {


                                     if ($data['fecha_muerte'] == 0) {
                        $fecha_muerte = '<span class="badge badge-pill badge-success"><center><b>VIVO</b></center></span>';
                    } else {
                        $fecha_muerte = '<span class="badge badge-pill badge-danger"><center><b>FALLECIDO</b>
                        </center></span>'; 

                    }

                   
                             ?>
                                <tr>
                                    <td><b>CL SAG</b> <?php echo $data['diio']; ?></td>


                                    <td><b>

                                   <?php if($data['edad']== 0) { echo  "RECIEN NACIDO, 0 MESES"; }
                                    elseif ($data['edad']== 0.1) { echo $data['edad']*10; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']== 0.2) { echo $data['edad']*10; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']== 0.3) { echo $data['edad']*10; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']== 0.4) { echo $data['edad']*10; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']== 0.5) { echo $data['edad']*10; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']== 0.6) { echo $data['edad']*10; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']== 0.7) { echo $data['edad']*10; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']== 0.8) { echo $data['edad']*10; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']== 0.9) { echo $data['edad']*10; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']== 0.10) { echo $data['edad']*100; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']== 0.11) { echo $data['edad']*100; echo "&nbsp;MESES"; }
                                    elseif ($data['edad']>= 1) { echo $data['edad']; echo "&nbsp;AÑOS"; }



                                    ?></b></td>
                                    <td><?php  if ($data['sexo'] == 1) {echo "Macho"; } 
                                    else{echo "Hembra"; }?>
                                    </td>
                                    <td><?php echo $data['peso']; ?>&nbsp;Kg</td>
                                    <td><?php echo $data['altura']; ?>&nbsp;Mts</td>
                                    <td><?php echo $data['especie_animal']; ?></td>
                                    <td><?php echo $data['subraza']; ?></td>
                                    <td id="heading" ><?php echo $data['fecha_nacimiento']; ?></td>
                                    <td id="heading2"><center><?php echo $fecha_muerte; ?></center>
                                        <?php  if ($data['fecha_muerte'] == 0) {echo ""; } 
                                    else{ echo $data['fecha_muerte']; }?>
                                    </td>
                                    <td><?php echo $data['fecha_ingreso']; ?></td>
                                   <td>
                                  
                                        <a href="editar_animal.php?id_animal=<?php echo $data['id_animal']; ?>" class="btn btn-success" style="background-color: #006110;"><i class='fas fa-edit'></i> Editar</a>
                                    
                                        <a href="ver_observaciones.php?id_animal=<?php echo $data['id_animal']; ?>" class="btn " style="background-color: #EAFE15;"><i class='fas fa-edit'></i>ver observacion</a>
                                        
                                    </td>    
                                    <?php } ?>
                                </tr>
                        <?php }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>      
     <?php include_once "js/validacion.js";  ?>
<?php include_once "includes/footer.php"; ?>
