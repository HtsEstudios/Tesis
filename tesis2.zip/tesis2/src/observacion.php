<?php include_once "includes/header.php";
date_default_timezone_set('America/Santiago');
require_once 'vendor/autoload.php'; // requerimos el autoloader para cargar todo lo que necesitemos de las librerías de composer
use Verot\Upload\Upload;
 include_once "js/tiempo_alert.js";
include "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "ejemplares";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
if (!empty($_POST)){
    $alert = "";
    if (empty($_POST['nombre']) || empty($_POST['descripcion']) || empty($_POST['fecha_observacion']) || empty($_POST['id_animal'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        Todo los campos son obligatorios
        </div>';
    } else {

        $archivo = $_FILES['foto']['tmp_name'];
        $foto = "img/" .$_FILES['foto']['name'];  
       
        move_uploaded_file($archivo, $foto);

        $nombre                = $_POST['nombre'];
        $descripcion           = $_POST['descripcion'];
        $fecha_observacion     = $_POST['fecha_observacion'];
        $nota_observacion      = $_POST['nota_observacion'];
        $id_animal             = $_POST['id_animal'];
        $date = date('Y-m-d');   
        $categorizacion        = $_POST['categorizacion'];
        $sub_categorizacion    = $_POST['sub_categorizacion'];
        $coordenada_x        = $_POST['coordenada_x'];
        $coordenada_y       = $_POST['coordenada_y'];

        


$query = mysqli_query($conexion, "SELECT * FROM observacion where foto = '$foto'");

        $result = mysqli_fetch_array($query);
        if ($result > 0) {
            $alert = '<div class="alert alert-warning" role="alert">
                        El diio ya existe
                    </div>';
        } else {
        
                $query_insert = mysqli_query($conexion, "INSERT INTO observacion(nombre,foto,descripcion,fecha_observacion,nota_observacion,id_animal,fecha_ingreso,categorizacion,sub_categorizacion,coordenada_x,coordenada_y) values ('$nombre', '$foto', '$descripcion', '$fecha_observacion', '$nota_observacion', '$id_animal', '$date', '$categorizacion', '$sub_categorizacion', '$coordenada_x', '$coordenada_y')");

            if ($query_insert) {
                $alert = '<div class="alert alert-primary" role="alert">
                            Observación registrada

                        </div>';
                    
            } else {
                $alert = '<div class="alert alert-danger" role="alert">
                        Error al registrar la observación
                    </div>';
            }
        }
    }
}

?>


<div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray">Panel de Observación</h1> <?php echo isset($alert) ? $alert : ''; ?>
    </div>
    <div>
<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#nueva_observacion" style="background-color: #006110;"><i class="fas fa-plus"></i></button>
<a href="animal.php"><button class="btn" type="button" style="background-color: #EAFE15" >Animal</button></a>
<a href="graficos.php"><button class="btn" type="button" style="background-color: #73FF00" >Grafico</button></a>

</div></br>
<div id="nueva_observacion" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header  text-white" style="background-color: #006110;">
                <h5 class="modal-title" id="my-modal-title" >Nueva Observación</h5>
                    <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <form action="" enctype="multipart/form-data" method="post" autocomplete="off" >
                    <?php echo isset($alert) ? $alert : ''; ?>


                        <div class="form-group">
                            <label for="">ID del Ejemplar</label>
                            <select name="id_animal" id="id_animal" class="form-control">
                        <?php
                        $query_rol = mysqli_query($conexion, " SELECT a.id_animal, a.edad, a.sexo, a.peso, a.altura, a.diio, a.fecha_nacimiento, a.fecha_muerte,
                         a.fecha_ingreso, r.especie_animal, r.subraza FROM  animal a INNER JOIN raza r ON a.id_raza = r.id_raza");
                        mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($id_animal = mysqli_fetch_array($query_rol)) {
                        ?>
                               <option value="<?php echo $id_animal["id_animal"]; ?>"><b>CL SAG </b><?php echo $id_animal["diio"] ?>&nbsp;<?php echo $id_animal["subraza"] ?></option>
                        <?php
                            }
                        }
                        ?>
                        </select></div>

                     <div class="form-group">
                        <label for="nombre">Nombre:</label>
                        <input type="text" class="form-control" placeholder="Ingrese el nombre de la observación" name="nombre" id="nombre"  minlength="3"  maxlength="30" required>
                    </div>
                    
                      <label for="foto">Foto:</label>
                      <div class="form-group">
                           <input type="file" class="form-control form-control-file" name="foto" id="foto" required>          
                          </label>
                     </div>
                        
                         <div class="form-group">
                            <label>Descripción:</label>
                            <input type="text" step="0.01" name="descripcion" class="form-control" id="descripcion" placeholder="Ingrese la descripcion de la observación." minlength="10"  maxlength="300" required>
                        </div>

                            <label for="fecha_observacion">Fecha en la cual se vio la observación:</label>
                            <div class="input-group date" data-provide="datepicker">
                          <input type="date" class="form-control" name="fecha_observacion"  id="fecha_observacion" minDate="0" maxDate="10">
                            <div class="input-group-addon">
                            <span class="glyphicon glyphicon-th"></span>
                              </div>
                            </div>

                                <script type="text/javascript">
                                     $(function(){


                                            $("#fecha_observacion").datepicker({ dateFormat: 'yy-mm-dd', minDate:(0), maxDate:(0)
                                          });
                                            $("#from").datepicker({ dateFormat: 'yy-mm-dd' }).bind("change",function(){
                                                var minValue = $(this).val();
                                               
                                                minValue = $.datepicker.parseDate("yy-mm-dd", minValue);
                                                minValue.setDate(minValue.getDate()+1);
                                                $("#fecha_observacion").datepicker( "option", "minDate", minValue);
                                              
                               
                                            })
                                        });


                                </script>

                    

          <div class="form-group">
        <label for="categorizacion">Categorización</label>                                                 
            <select name="categorizacion" id="categorizacion"  data-placeholder="- Seleccione categorizacion -"
             class="form-control chosencategorizacion" onchange="change(this.id, 'sub_categorizacion')"
             value="<%= typeof categorizacion != 'undefined' ? categorizacion : '' %>">
                              <option value=""></option>                 
                               <option value="1" >c1: Emergencia vital </option>
                               <option value="2" >c2: Emergencia evidente</option>
                               <option value="3" >c3: Urgencia</option>
                               <option value="4" >c4: Urgencia leve</option>
                               <option value="5" >c5: Consulta general</option>
            </select>
      </div>
      <div class="form-group">
        <label for="sub_categorizacion">Sub Categorizaciones</label>
          <select id="sub_categorizacion" name="sub_categorizacion" data-placeholder="- Seleccione sub_categorizacion -"
          class="form-control chosensub_categorizacion" value="<%= typeof sub_categorizacion != 'undefined' ? sub_categorizacion : '' %>" >
            <option value=""></option>
          </select>
      </div>
            
                      

                             <script>
        //chosen institución
        $('.chosencategorizacion, .chosensub_categorizacion').chosen({no_results_text: "No hay resultados...",allow_single_deselect: true});
        $(".chosencategorizacion").chosen().on("change", function(event) { 
                            document.getElementById('sub_categorizacion').value = "" ;
                            $(".chosensub_categorizacion").trigger('chosen:updated');                                                                                                       
                            });
        $(".chosensub_categorizacion").chosen().on("chosen:showing_dropdown", function(event) {  
                            $(".chosensub_categorizacion").trigger('chosen:updated');                                                                           
                            });
        </script>

     <div class="form-group">                       
                               <label for="nota_observacion">Nota de observación</label>
                               <select name="nota_observacion" id="nota_observacion" class="form-control">
                               <option value="1" >Nota 1</option>
                               <option value="2" >Nota 2</option>
                               <option value="3" >Nota 3</option>
                               <option value="4" >Nota 4</option>
                               <option value="5" >Nota 5</option>
                               <option value="6" >Nota 6</option>
                               <option value="7" >Nota 7</option>
                               </select>
                        </div>   
            <div class="form-group">
                        <label >Coordenada GPS X: </label>
                        <input type="number" name="coordenada_x" id="coordenada_x" step="0.00001" class="form-control" placeholder="Ingrese coordenada_x"  >
                    </div>
            <div class="form-group">
                        <label >Coordenada GPS Y: </label>
                        <input type="number" name="coordenada_y" id="coordenada_y" step="0.00001" class="form-control" placeholder="Ingrese coordenada_y"   >
                    </div>
                    <script type="text/javascript">
                      coordenada_x.oninput = function () {
                                        if (this.value.length > 10) {
                                            this.value = this.value.slice(0,10); 
                                        
                                        }
                                    }

                         coordenada_y.oninput = function () {
                                        if (this.value.length > 10) {
                                            this.value = this.value.slice(0,10); 
                                    
                                        }
                                    }
                    </script>

                    <input type="submit" value="Registrar" class="btn btn-primary" style="background-color: #006110;">
              
                </form>
            </div>
        </div>
    </div>
</div>


<div class="col-lg-12">
              <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered mt-2" id="tbl">
                    <thead class="thead-dark">
                        <tr>
                            <th>DIIO</th>
                            <th>NOMBRE</th>
                            <th>FOTO</th>
                            <th>DESCRIPCIÓN</th>
                            <th>CATEGORIZACIÓN</th>
                            <th>SUB CATEGORIZACIÓN</th>
                            <th>FECHA OBSERVACIÓN</th>
                            <th>NOTA OBSERVACIÓN</th>
                            <th>COOR X</th>
                            <th>COOR Y</th>
                            <th>FECHA INGRESO</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>

<?php 

  require_once "conexion2.php";
  $conexion=conexion();
  


        if(isset($_SESSION['consulta'])){
          if($_SESSION['consulta'] > 0){
            $idp=$_SESSION['consulta'];
            $sql="SELECT o.id_observacion, o.nombre, o.foto, o.descripcion, o.fecha_observacion, o.nota_observacion, o.id_animal, o.fecha_ingreso, o.categorizacion, o.sub_categorizacion ,o.coordenada_x , o.coordenada_y, a.diio FROM  observacion o INNER JOIN animal a ON o.id_animal = a.id_animal where id_observacion='$idp'";
          }else{
            $sql="SELECT o.id_observacion, o.nombre, o.foto, o.descripcion, o.fecha_observacion, o.nota_observacion, o.id_animal, o.fecha_ingreso, o.categorizacion, o.sub_categorizacion ,o.coordenada_x , o.coordenada_y, a.diio FROM  observacion o INNER JOIN animal a ON o.id_animal = a.id_animal";
          }
        }else{
          $sql="SELECT o.id_observacion, o.nombre, o.foto, o.descripcion, o.fecha_observacion, o.nota_observacion, o.id_animal, o.fecha_ingreso, o.categorizacion, o.sub_categorizacion ,o.coordenada_x , o.coordenada_y, a.diio FROM  observacion o INNER JOIN animal a ON o.id_animal = a.id_animal";
        }

        $result=mysqli_query($conexion,$sql);
        while($data=mysqli_fetch_row($result)){ 

          $datos=$data[12]."||".
               $data[1]."||".
               $data[2]."||".
               $data[3]."||".
               $data[8]."||".
               $data[9]."||".
               $data[4]."||".
               $data[5]."||".
               $data[10]."||".
               $data[11]."||".
               $data[7];
       ?>

      <tr>
        <td><b>CL SAG</b>&nbsp;<?php echo $data[12] ?></td>
        <td><?php echo $data[1] ?></td>
        <td><img width="200" height="100" src="<?php echo $data['2']; ?>"></td>
        <td><?php echo $data[3] ?></td>
        <td><?php  
           if ($data['8'] == 1) {echo "c1: Emergencia vital"; } 
                                          elseif ($data['8'] == 2) {echo "c2: Emergencia Evidente"; }
                                           elseif ($data['8'] == 3) {echo "c3: Urgencia"; } 
                                            elseif ($data['8'] == 4) {echo "c4: Urgencia leve"; } 
                                             elseif ($data['8'] == 5) {echo "c5: Consulta general"; }  
                  ?>
        </td>
        <td><?php 
           if ($data['9'] == 1) {echo "Infarto"; } 
                                          elseif ($data['9'] == 2) {echo "Hemorragia masiva"; }
                                           elseif ($data['9'] == 3) {echo "Lengua azul (Denuncia sag)"; } 
                                            elseif ($data['9'] == 4) {echo "Salmonela"; } 
                                             elseif ($data['9'] == 5) {echo "Tuberculosis (Denuncia sag)"; } 
                                              elseif ($data['9'] == 6) {echo "Peste bubónica"; }
                                           elseif ($data['9'] == 7) {echo "Viruela"; } 
                                            elseif ($data['9'] == 8) {echo "Fiebre aftosa (Denunciar sag)"; } 
                                             elseif ($data['9'] == 9) {echo " Accidente Mortal o con consecuencia"; }
                                              elseif ($data['9'] == 10) {echo "Problema broncopulmonar"; }
                                           elseif ($data['9'] == 11) {echo "Secreciones de sangrado"; } 
                                            elseif ($data['9'] == 12) {echo "Problema de movimiento"; } 
                                             elseif ($data['9'] == 13) {echo "Accidente evidente"; }
                                              elseif ($data['9'] == 14) {echo "Tétanos"; }
                                           elseif ($data['9'] == 15) {echo "Cólicos"; } 
                                            elseif ($data['9'] == 16) {echo "Cálculos"; } 
                                             elseif ($data['9'] == 17) {echo "Anemia"; }
                                              elseif ($data['9'] == 18) {echo "Atrofia muscular"; }
                                           elseif ($data['9'] == 19) {echo "Hongos epidurales"; } 
                                            elseif ($data['9'] == 20) {echo "Hongos faciales"; } 
                                             elseif ($data['9'] == 21) {echo "Gripe"; }
                                              elseif ($data['9'] == 22) {echo "Diarrea"; }
                                           elseif ($data['9'] == 23) {echo "Dermatitis"; } 
                                            elseif ($data['9'] == 24) {echo "Accidente"; } 
                                             elseif ($data['9'] == 25) {echo "Sospecha de enfermedad"; }
                                              elseif ($data['9'] == 26) {echo "Análisis calidad de estatus"; }
                                           elseif ($data['9'] == 27) {echo "Otros"; } 
 ?>
        </td>
        <td><?php echo $data[4] ?></td>
        <td><?php echo $data[5] ?></td>
        <td><?php echo $data[10] ?></td>
        <td><?php echo $data[11] ?></td>
        <td><?php echo $data[7] ?></td>
        <td>
                                  
     <a href="editar_observacion.php?id_observacion=<?php echo $data['0']; ?>" class="btn btn-success" style="background-color: #006110;"><i class='fas fa-edit'></i> Editar</a>
       </td>    
      </tr>
      <?php } ?>
     </tbody>
    </table>
 </div> </div>
       
        <script src="js/validacion3.js" type="text/javascript"></script>  
        <script src="js\validacion2.js" type="text/javascript"></script>        
        <?php     include "js/validacion.js"  ?>
       <script type = "text/javascript" src = 'js\sub_categorizacion.js' ></script> 
       <script src="js\jquery-3.4.1.min.js" ></script>
       <script src="js\chosen.jquery.js" type="text/javascript"></script>
 <?php include_once "includes/footer.php"; ?>

    