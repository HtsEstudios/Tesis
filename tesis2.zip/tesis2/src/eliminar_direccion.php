<?php
require("../conexion.php");
 include_once "js/tiempo_alert.js";
$id_user = $_SESSION['idUser'];
$permiso = "establecimiento";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d 
	ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");

if (!empty($_GET['direccion_id'])) {
    require("../conexion.php");
    $direccion_id = $_GET['direccion_id'];
    $query_delete = mysqli_query($conexion, "DELETE FROM direccion_establecimiento WHERE direccion_id = $direccion_id");
    mysqli_close($conexion);
    header("location: direccion.php");
}
?>