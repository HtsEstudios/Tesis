<?php include_once "includes/header.php";
 include_once "js/tiempo_alert.js";
date_default_timezone_set('America/Santiago');
include "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "establecimiento";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}
if (!empty($_POST)) {
    $alert = "";
    if (empty($_POST['rup'])|| empty($_POST['coordenada_x']) || empty($_POST['coordenada_y'])  || empty($_POST['oficina_sag'])|| empty($_POST['tipo_ubicacion'])|| empty($_POST['tipo_establecimiento']) || empty($_POST['sucesion']) || empty($_POST['nombre_establecimiento']) || empty($_POST['hectarea']) || empty($_POST['criterio_de_riesgo'])|| empty($_POST['direccion_id'])|| empty($_POST['run'])) {
        $alert = '<div class="alert alert-danger" role="alert">
        Todo los campos son obligatorios
        </div>';
    } else {
        
        $id_establecimiento           = $_GET['id_establecimiento'];
        $rup                          = $_POST['rup'];
        $coordenada_x                 = $_POST['coordenada_x'];
        $coordenada_y                 = $_POST['coordenada_y'];
        $oficina_sag                  = $_POST['oficina_sag'];
        $tipo_ubicacion               = $_POST['tipo_ubicacion'];
        $tipo_establecimiento         = $_POST['tipo_establecimiento'];
        $sucesion                     = $_POST['sucesion'];
        $nombre_establecimiento       = $_POST['nombre_establecimiento'];
        $hectarea                     = $_POST['hectarea'];
        $criterio_de_riesgo           = $_POST['criterio_de_riesgo'];
        $direccion_id                 = $_POST['direccion_id'];
        $run                          = $_POST['run'];
       

  $sql_update = mysqli_query($conexion, "UPDATE establecimiento SET rup = '$rup',
                                                           coordenada_x = '$coordenada_x',
                                                           coordenada_y = '$coordenada_y',
                                                           oficina_sag = '$oficina_sag', 
                                                           tipo_ubicacion = '$tipo_ubicacion', 
                                                           tipo_establecimiento = '$tipo_establecimiento', 
                                                           sucesion = '$sucesion',
                                                           nombre_establecimiento = '$nombre_establecimiento',
                                                           hectarea = '$hectarea', 
                                                           criterio_de_riesgo = '$criterio_de_riesgo', 
                                                           direccion_id = '$direccion_id', 
                                                           run = '$run'
                                                           WHERE id_establecimiento = $id_establecimiento");

        $alert = '<div class="alert alert-success" role="alert">establecimiento Actualizado</div>';

    }

}

if (empty($_REQUEST['id_establecimiento'])) {
    header("Location: establecimiento.php");
}
$id_establecimiento = $_REQUEST['id_establecimiento'];
$sql = mysqli_query($conexion, "SELECT * FROM establecimiento WHERE id_establecimiento = $id_establecimiento");
$result_sql = mysqli_num_rows($sql);
if ($result_sql == 0) {
    header("Location: establecimiento.php");
} else {
    if ($data = mysqli_fetch_array($sql)) {
        $id_establecimiento           = $data['id_establecimiento'];
        $rup                          = $data['rup'];
        $coordenada_x                 = $data['coordenada_x'];
        $coordenada_y                 = $data['coordenada_y'];
        $oficina_sag                  = $data['oficina_sag'];
        $tipo_ubicacion               = $data['tipo_ubicacion'];
        $tipo_establecimiento         = $data['tipo_establecimiento'];
        $sucesion                     = $data['sucesion'];
        $nombre_establecimiento       = $data['nombre_establecimiento'];
        $hectarea                     = $data['hectarea'];
        $criterio_de_riesgo           = $data['criterio_de_riesgo'];
        $direccion_id                 = $data['direccion_id'];
        $run                          = $data['run'];
    }
}
?>
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-6 m-auto">
            <div class="card">
                <div class="card-header  text-white" style="background-color: #006110;">
                    Modificar establecimiento
                </div>
                <div class="card-body">
                  <form class="" action="" method="post">
                    <?php echo isset($alert) ? $alert : ''; ?>
                     <input type="hidden" name="id_establecimiento" id="id_establecimiento" value="<?php echo $id_establecimiento; ?>">

                    <div class="form-group">
                        <label for="rup">rup: </label>
                        <input type="number" class="form-control" placeholder="Ingrese rup" name="rup" id="rup"  value="<?php echo $rup; ?>"  required>
                    </div>
                  
                    <div class="form-group">
                        <label for="coordenada_x">Coordenada GPS X: </label>
                        <input type="number" step="0.00001" class="form-control" placeholder="Ingrese coordenada_x" name="coordenada_x" id="coordenada_x"  value="<?php echo $coordenada_x; ?>"    required>
                    </div>
                         <div class="form-group">
                            <label>Coordenada GPS y:</label>
                            <input type="number" step="0.00001" name="coordenada_y" class="form-control" id="coordenada_y" placeholder="Ingrese coordenada_y"  value="<?php echo $coordenada_y; ?>"  required>
                        </div>

                             <script type="text/javascript">
                      coordenada_x.oninput = function () {
                                        if (this.value.length > 10) {
                                            this.value = this.value.slice(0,10); 
                                        
                                        }
                                    }

                         coordenada_y.oninput = function () {
                                        if (this.value.length > 10) {
                                            this.value = this.value.slice(0,10); 
                                    
                                        }
                                    }
                                          </script>
                
                
                         <div class="form-group">
                            <label>oficina_sag:</label>
                            <input type="text" name="oficina_sag" class="form-control" id="oficina_sag" placeholder="oficina que corresponde tu establecimiento "  value="<?php echo $oficina_sag; ?>" minlength="4"  maxlengt="20" required>
                        </div>
                        
                        <div class="form-group">
                          <label for="tipo_ubicacion">tipo ubicacion</label>
                          <select name="tipo_ubicacion" id="tipo_ubicacion" class="form-control" value="<?php echo $tipo_ubicacion; ?>">
                             <option value="1" <?php  if ($tipo_ubicacion == 1) {
                                                echo "selected";
                                              }
                                              ?>>absoluta</option>

                            <option value="2" <?php    if ($tipo_ubicacion == 2) {
                                                echo "selected";
                                              }
                                              ?>>relativa</option>

                              </select></div>
                        
                               <div class="form-group">
                          <label for="tipo_establecimiento">tipo establecimiento</label>
                          <select name="tipo_establecimiento" id="tipo_establecimiento" class="form-control" value="<?php echo $tipo_establecimiento; ?>">

                            <option value="1" <?php  if($tipo_establecimiento == 1) {
                                                echo "selected";
                                              }
                                              ?>>PREDIO</option>

                            <option value="2" <?php    if($tipo_establecimiento == 2) {
                                                echo "selected";
                                              }
                                              ?>>MATADERO</option>
                             <option value="3" <?php if($tipo_establecimiento == 3) {
                                                echo "selected";
                                              }
                                              ?>>CFA</option>

                            <option value="4" <?php   if($tipo_establecimiento == 4) {
                                                echo "selected";
                                              }
                                              ?>>RECINTO FERIAL</option>
                            <option value="5" <?php   if($tipo_establecimiento == 5) {
                                                echo "selected";
                                              }
                                              ?>>TRASPATIO</option>

                              </select>
                        </div>





                        <div class="form-group">
                            <label>sucesion:</label>
                            <input type="text" name="sucesion" class="form-control"  id="sucesion" placeholder="sucesion "  value="<?php echo $sucesion; ?>" minlength="4"  maxlength="20" required>
                        </div>
                        <div class="form-group">
                            <label>nombre establecimiento:</label>
                            <input type="text" name="nombre_establecimiento" class="form-control"  id="nombre_establecimiento" placeholder="nombre_establecimiento "  value="<?php echo $nombre_establecimiento; ?>" minlength="4"  maxlength="20" required>
                        </div>
                     
                        <div class="form-group">
                            <label>hectárea:</label>
                            <input type="number" name="hectarea" class="form-control" id="hectarea" placeholder="hectarea "  value="<?php echo $hectarea; ?>"  required>
                        </div>
                        <script type="text/javascript">
                            hectarea.oninput = function () {
                                        if (this.value.length > 6) {
                                            this.value = this.value.slice(0,6); 
                                    
                                        }
                                    }

                        </script>

                        
                              <div class="form-group">
                          <label for="criterio_de_riesgo">criterio de riesgo</label>
                          <select name="criterio_de_riesgo" id="criterio_de_riesgo" class="form-control" value="<?php echo $criterio_de_riesgo; ?>">
                            <option value="1" <?php  if($criterio_de_riesgo == 1) {
                                                echo "selected";
                                              }
                                              ?>>CAMPO DE PASTOREO CORDILLERANO LIMÍTROFE</option>

                            <option value="2" <?php    if($criterio_de_riesgo == 2) {
                                                echo "selected";
                                              }
                                              ?>>CAMPO DE PASTOREO CORDILLERANO NO LIMÍTROFE</option>
                             <option value="3" <?php if($criterio_de_riesgo == 3) {
                                                echo "selected";
                                              }
                                              ?>>UNIDAD EPIDEMIOLÓGICA</option>

                            <option value="4" <?php   if($criterio_de_riesgo == 4) {
                                                echo "selected";
                                              }
                                              ?>>HUMEDALES</option>
                            <option value="5" <?php   if($criterio_de_riesgo == 5) {
                                                echo "selected";
                                              }
                                              ?>>CUARENTENA DE INTERNACIÓN</option>
                             <option value="6" <?php if($criterio_de_riesgo == 6) {
                                                echo "selected";
                                              }
                                              ?>>BIOTERIO</option>

                            <option value="7" <?php   if($criterio_de_riesgo == 7) {
                                                echo "selected";
                                              }
                                              ?>>CAMPO LIMÍTROFE</option>
                            <option value="8" <?php   if($criterio_de_riesgo == 8) {
                                                echo "selected";
                                              }
                                              ?>>SIN CRITERIO DE RIESGO</option>

                              </select>
                        </div>

                        <div class="form-group">
                    <label>direccion</label>
                    <select name="direccion_id" id="direccion_id" class="form-control"  value="<?php echo $direccion_id; ?>">
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from direccion_establecimiento");
                        //mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($direccion_id2 = mysqli_fetch_array($query_rol)) {
                        ?>
                                 <option value="<?php echo $direccion_id2["direccion_id"]; ?>"<?=$direccion_id2['direccion_id'] == $direccion_id ? ' selected="selected"' : '';?>  ><?php echo $direccion_id2["direccion"]?>&nbsp;<?php echo $direccion_id2["numero"]?></option>
                        <?php

                            }
                        }

                        ?>
                    </select></div>
                        <div class="form-group">
                    <label>run titular</label>
                    <select name="run" id="run" class="form-control"  value="<?php echo $titular; ?>">
                        <?php
                        $query_rol = mysqli_query($conexion, " select * from titular");
                       mysqli_close($conexion);
                        $resultado_rol = mysqli_num_rows($query_rol);
                        if ($resultado_rol > 0) {
                            while ($run2 = mysqli_fetch_array($query_rol)) {
                        ?>
                                 <option value="<?php echo $run2["run"]; ?>"<?=$run2['run'] == $run ? ' selected="selected"' : '';?>  ><?php echo $run2["nombre"] ?></option>
                        <?php

                            }
                        }

                        ?>
                    </select></div>   
                    <button type="submit" class="btn btn-primary"  style="background-color: #006110;"><i class="fas fa-user-edit"></i></button>
                    <a href="establecimiento.php" class="btn btn-danger">Atras</a>
                </form>
            </div>
        </div>
    </div>
</div>
</div>    
    <?php     include "js/validacion.js";  ?>
    <?php include_once "includes/footer.php"; ?>