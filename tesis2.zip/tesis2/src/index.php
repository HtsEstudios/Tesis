<?php include_once "includes/header.php";
require "../conexion.php";
 include_once "js/tiempo_alert.js";
$usuarios = mysqli_query($conexion, "SELECT * FROM usuario");
$totalU= mysqli_num_rows($usuarios);
$animal = mysqli_query($conexion, "SELECT * FROM animal");
$totalC = mysqli_num_rows($animal);
$establecimiento = mysqli_query($conexion, "SELECT * FROM establecimiento");
$totalP = mysqli_num_rows($establecimiento);
$observacion = mysqli_query($conexion, "SELECT * FROM observacion");
$totalO = mysqli_num_rows($observacion);





require "../conexion.php";
$Fechas = mysqli_query($conexion, "SELECT DISTINCT(fecha_ingreso) FROM observacion ORDER BY fecha_ingreso");
$totalfechas = mysqli_fetch_all($Fechas);
$obs = array();
foreach ($totalfechas as $fecha) {
    $temp = mysqli_query($conexion, "SELECT COUNT(id_observacion) FROM observacion WHERE fecha_ingreso='$fecha[0]'");
    $tempo = mysqli_fetch_all($temp);
    array_push($obs, $tempo[0]);
}
//------------
$Fechass = mysqli_query($conexion, "SELECT DISTINCT(fecha_nacimiento) FROM animal ORDER BY fecha_nacimiento");
$totalfechass = mysqli_fetch_all($Fechass);
$obss = array();
foreach ($totalfechass as $fechaa) {
    $tempp = mysqli_query($conexion, "SELECT COUNT(fecha_nacimiento) FROM animal WHERE fecha_nacimiento='$fechaa[0]'");
    $tempoo = mysqli_fetch_all($tempp);
    array_push($obss, $tempoo[0]);
}
?>




    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray"><b>Panel de Administración</b></h1>
    </div>

    <!-- Content Row -->
    <div class="row">
        <a class="col-xl-3 col-md-6 mb-4" href="usuarios.php">
            <div class="card border-left-primary shadow h-100 py-2 bg-warning">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">Usuarios totales</div>
                            <div class="h1 mb-0 align-items-center font-weight-bold text-white"><?php echo $totalU; ?></div>
                        </div>
                        <div class="col-auto">
                             <i class="fas fa-chart-pie  fa-2x"></i>                        </div>
                    </div>
                </div>
            </div>
        </a>

        <!-- Earnings (Monthly) Card Example -->
        <a class="col-xl-3 col-md-6 mb-4" href="animal.php">
            <div class="card border-left-success shadow h-100 py-2 bg-success">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">animales totales</div>
                            <div class="h1 mb-0 center font-weight-bold text-white"><?php echo $totalC; ?></div>
                        </div>
                        <div class="col-auto">
                          <i class="fas fa-horse  fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </a>



<a class="col-xl-3 col-md-6 mb-4" href="animal.php">
            <div class="card border-left-success shadow h-100 py-2 bg-primary">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">Establecimiento totales</div>
                            <div class="h1 mb-0 center font-weight-bold text-white"><?php echo $totalP; ?></div>
                        </div>
                        <div class="col-auto">
                          <i class="fas fa-school fa-2x" style="background-color: #FF0000;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        <a class="col-xl-3 col-md-6 mb-4" href="observacion.php">
            <div class="card border-left-success shadow h-100 py-2 bg-danger">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">Observaciones totales</div>
                            <div class="h1 mb-0 center font-weight-bold text-white"><?php echo $totalO; ?></div>
                        </div>
                        <div class="col-auto">
                          <i class="fas fa-book-open  fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </a>
       




 <div class="col-lg-6">
            <div class="au-card m-b-30">
                <div class="au-card-inner">
                    <h4 ><b>ANIMAL POR FECHA DE NACIMIENTO</b></h5>
                    <canvas id="g_animal"></canvas>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="au-card m-b-30">
                <div class="au-card-inner">
                    <h4 ><b>OBSERVACIÓN INGRESADO POR FECHA</b> </h5>
                    <canvas id="g_observacion"></canvas>
                </div>
            </div>
        </div>
      






  
<?php include_once "includes/footer.php"; ?>
<?php include "js/grafico.js"; ?>

<?php include "js/grafico1.js"; ?>



 



<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
