<?php include_once "includes/header.php";
 include_once "js/tiempo_alert.js";
date_default_timezone_set('America/Santiago');
include "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "ejemplares";
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: p.php");
}


 
require "../conexion.php";
$Observaciones = mysqli_query($conexion, "SELECT AVG(nota_observacion) FROM observacion");
$totalO = mysqli_fetch_all($Observaciones);

$animal = mysqli_query($conexion, "SELECT * FROM animal");
$totalC = mysqli_num_rows($animal);

$observacion = mysqli_query($conexion, "SELECT * FROM observacion");
$totalO0 = mysqli_num_rows($observacion);





//------------fecha nacimiento
$Fechasss = mysqli_query($conexion, "SELECT DISTINCT(fecha_nacimiento) FROM animal ORDER BY fecha_nacimiento");
$totalfechasss = mysqli_fetch_all($Fechasss);
$obsss = array();
foreach ($totalfechasss as $fechaaa) {
    $temppp = mysqli_query($conexion, "SELECT COUNT(id_animal) FROM animal WHERE fecha_nacimiento='$fechaaa[0]'");
    $tempooo = mysqli_fetch_all($temppp);
    array_push($obsss, $tempooo[0]);
}
//------------fecha muerte
$Fechassss = mysqli_query($conexion, "SELECT DISTINCT(fecha_muerte) FROM animal ORDER BY fecha_muerte");
$totalfechassss = mysqli_fetch_all($Fechassss);
$obssss = array();
foreach ($totalfechassss as $fechaaaa) {
    $tempppp = mysqli_query($conexion, "SELECT COUNT(id_animal) FROM animal WHERE fecha_muerte='$fechaaaa[0]'");
    $tempoooo = mysqli_fetch_all($tempppp);
    array_push($obssss, $tempoooo[0]);
}
//------------raza 
$Fechassssa = mysqli_query($conexion, "SELECT DISTINCT(r.especie_animal)  FROM animal a  INNER JOIN raza r on a.id_raza = r.id_raza ORDER by r.especie_animal");
$totalfechassssa = mysqli_fetch_all($Fechassssa);
$obssssa = array();
foreach ($totalfechassssa as $fechaaaad) {
    $temppppa = mysqli_query($conexion, "SELECT COUNT(id_animal) FROM animal a  INNER JOIN raza r on a.id_raza = r.id_raza WHERE r.especie_animal='$fechaaaad[0]'");
    $tempooooa = mysqli_fetch_all($temppppa);
    array_push($obssssa, $tempooooa[0]);
}
//------------raza 
$Fechassssa = mysqli_query($conexion, "SELECT DISTINCT(r.nombre_establecimiento)  FROM animal a  INNER JOIN establecimiento r on a.id_establecimiento = r.id_establecimiento ORDER by r.nombre_establecimiento");
$totalfechassssad = mysqli_fetch_all($Fechassssa);
$obssssad = array();
foreach ($totalfechassssad as $fechaaaada) {
    $temppppad = mysqli_query($conexion, "SELECT COUNT(id_animal) FROM animal a  INNER JOIN establecimiento r on a.id_establecimiento = r.id_establecimiento WHERE r.nombre_establecimiento='$fechaaaada[0]'");
    $tempooooad = mysqli_fetch_all($temppppad);
    array_push($obssssad, $tempooooad[0]);
}



?>

        
          
          
         
 

<div><h1><b>Panel de Graficos</b></h1></div>

<div class="row">
<a class="col-xl-3 col-md-6 mb-4" href="animal.php">
            <div class="card border-left-warning shadow h-100 py-2 bg-warning">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">Promedio nota observaciones</div>
                            <div class="h1 mb-0 font-weight-bold text-white"><?php echo $totalO[0][0]; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="  fas fa-chart-line  fa-2x"></i> 
                        </div>
                    </div>
                </div>
            </div>
        </a>
<a class="col-xl-3 col-md-6 mb-4" href="animal.php">
            <div class="card border-left-success shadow h-100 py-2 bg-success">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">Animales totales</div>
                            <div class="h1 mb-0 center font-weight-bold text-white"><?php echo $totalC; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-horse  fa-2x"></i>
                                                    </div>
                    </div>
                </div>
            </div>
        </a>
         <a class="col-xl-3 col-md-6 mb-4" href="observacion.php">
            <div class="card border-left-info shadow h-100 py-2 bg-danger">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">Observaciones totales </div>
                         
                                    <div class="h1 align-items-center mb-0 mr-3 font-weight-bold text-white"><?php echo $totalO0; ?></div>
                                </div>
                                  <div class="col-auto">
                                   <i class="fas fa-book  fa-2x"></i>
                                    </div>
                          
                        </div>

                        </div>
                    </div>

       
        </a>
</div>
<div class="row">
  
  

        
 <div class="col-lg-6">
            <div class="au-card m-b-30">
                <div class="au-card-inner">
                    <h4 class="title-2 m-b-40"><b>INGRESO TOTAL DE ANIMAL POR FECHA</b></h4>
                    <canvas id="o_fecha"></canvas>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="au-card m-b-30">
                <div class="au-card-inner">
                    <h4 class="title-2 m-b-40"><b>INGRESO TOTAL DE EJEMPLAR POR RAZA</b></h4>
                    <canvas id="a_a"></canvas>
                </div>
            </div>
        </div>
       <div class="col-lg-6">
            <div class="au-card m-b-30">
                <div class="au-card-inner">
                    <h4 class="title-2 m-b-40"><b>INGRESO TOTAL DE EJEMPLAR POR ESTABLECIMIENTO</b></h4>
                    <canvas id="a_aa"></canvas>
                </div>
            </div>
        </div>

 <div class="col-lg-6">
            <div class="au-card m-b-30">
                <div class="au-card-inner">
                    <h4 class="title-2 m-b-40"><b>INGRESO TOTAL POR FECHA DE FALLECIMIENTO</b></h4>
                    <canvas id="f_fallecimiento"></canvas>
                </div>
            </div>
        </div>

</div>


  
<?php include_once "includes/footer.php"; ?>
<?php include "js/grafico5.js"; ?>
<?php include "js/grafico4.js"; ?>
<?php include "js/grafico3.js"; ?>
<?php include "js/grafico2.js"; ?>
<?php include "js/grafico1.js"; ?>
<?php include "js/grafico.js"; ?>


      
