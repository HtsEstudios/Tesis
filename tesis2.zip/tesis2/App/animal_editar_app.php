<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
    include_once 'conexion_App.php';

            $edad=$_POST['edad'];
            $sexo=$_POST['sexo'];
            $peso=$_POST['peso'];
            $altura=$_POST['altura'];
            $diio=$_POST['diio'];
            $id_establecimiento=$_POST['id_establecimiento'];
            $id_raza=$_POST['id_raza'];
            $fecha_nacimiento=$_POST['fecha_nacimiento'];
            $fecha_muerte=$_POST['fecha_muerte'];

    $query="UPDATE animal SET edad='".$edad."',sexo='".$sexo."',peso='".$peso."',
                              altura='".$altura."',diio='".$diio."',id_establecimiento='".$id_establecimiento."',
                              id_raza='".$id_raza."',fecha_nacimiento='".$fecha_nacimiento."',fecha_muerte='".$fecha_muerte."' WHERE diio='".$diio."'";
    $resultado=$mysql->query($query);
    if($mysql->affected_rows>0 && $resultado==true){
        echo "El animal se edito exitosamente";

    }else{
        echo "Error al editar animal";
    }
    $mysql->close();
}