<?php
if($_SERVER["REQUEST_METHOD"]=="GET"){
    require_once 'conexion_App.php';
    $diio=$_GET['diio'];
    $query="SELECT * FROM animal WHERE diio='".$diio."'";
    $resultado=$mysql->query($query);
    if($mysql->affected_rows > 0){
        while($row=$resultado->fetch_assoc()){
            $array=$row;
        }
        echo json_encode($array);
    }else{
        echo "No hay registros";
    }
    $resultado->close();
    $mysql->close();
}