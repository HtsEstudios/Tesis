<?php
if($_SERVER["REQUEST_METHOD"]=="POST"){
    require_once 'conexion_App.php';
    $id_animal=$_POST['id_animal'];
    $query="DELETE FROM animal WHERE id_animal='".$id_animal."'";
    $resultado=$mysql->query($query);
    if($mysql->affected_rows > 0){
        if($resultado==true){
            echo "Usuario borrado exitosamente";
        }
    }else{
        echo "Error al borrar el usuario";
    }
    $mysql->close();
}