<?php
        if($_SERVER["REQUEST_METHOD"]=="POST"){
            date_default_timezone_set('America/Santiago');
            require_once 'conexion_App.php';

            $edad=$_POST['edad'];
            $sexo=$_POST['sexo'];
            $peso=$_POST['peso'];
            $altura=$_POST['altura'];
            $diio=$_POST['diio'];
            $id_establecimiento=$_POST['id_establecimiento'];
            $id_raza=$_POST['id_raza'];
            $fecha_nacimiento=$_POST['fecha_nacimiento'];
            $fecha_muerte=$_POST['fecha_muerte'];
           
            $date = date('Y-m-d H:i:s');

            //$query="INSERT INTO animal(edad,sexo,peso,altura,diio,id_establecimiento,id_raza,fecha_nacimiento,fecha_muerte,fecha_ingreso) 
            //        VALUES ('$edad','$sexo','$peso','$altura','$diio','$id_establecimiento','$id_raza','$fecha_nacimiento','$fecha_muerte','$date')";

            $query="INSERT INTO animal(edad,sexo,peso,altura,diio,id_establecimiento,id_raza,fecha_nacimiento,fecha_muerte,fecha_ingreso) 
                    VALUES ('".$edad."','".$sexo."','".$peso."','".$altura."','".$diio."','".$id_establecimiento."','".$id_raza."','".$fecha_nacimiento."','".$fecha_muerte."','".$date."')";

            $resultado=$mysql->query($query);


            
            if($resultado==true){
                echo "El animal se inserto de forma exitosa";
            }else{
                echo "Error al insertar el animal";
            }
    
            //$query = mysqli_query($conexion, "SELECT * FROM animal where diio = '$diio'");
    
            //$result = mysqli_fetch_array($query);
            //if ($result > 0) {
               // $alert = '<div class="alert alert-warning" role="alert">
                            //El diio ya existe
                        //</div>';
            //} else {
                //$query_insert = mysqli_query($conexion, "INSERT INTO animal(edad,sexo,peso,altura,diio,id_establecimiento,id_raza,fecha_nacimiento
                //,fecha_muerte,fecha_ingreso) values ('$edad', '$sexo', '$peso', '$altura', '$diio', '$id_establecimiento', '$id_raza'
                //, '$fecha_nacimiento',  '$fecha_muerte', '$date')");
                //if ($query_insert) {
                    //$alert = '<div class="alert alert-primary" role="alert">
                                //Ejemplar registrado
                            //</div>';
                //} else {
                   // $alert = '<div class="alert alert-danger" role="alert">
                      //      Error al registrar ejemplar
                   //     </div>';
               // }
            //}
        }