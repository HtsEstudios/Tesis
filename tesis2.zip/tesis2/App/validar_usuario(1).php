<?php
require_once "conexion_App.php";

$date = date('Y-m-d H:i:s');           
            $user = $_POST['usuario'];
            $clave = md5($_POST['clave']);
            $query = "SELECT * FROM usuario WHERE usuario = '$user' AND clave = '$clave' AND estado = 1";
          // mysqli_close($conexion);
          $resultado=$mysql->query($query);
          if($mysql->affected_rows > 0){
              while($row=$resultado->fetch_assoc()){
                  $array=$row;
              }
              echo json_encode($array);
          }else{
              echo "No";
          }
          $resultado->close();
          $mysql->close();


/*$query="SELECT * FROM animal WHERE diio='".$diio."'";
    $resultado=$mysql->query($query);
    if($mysql->affected_rows > 0){
        while($row=$resultado->fetch_assoc()){
            $array=$row;
        }
        echo json_encode($array);
    }else{
        echo "No hay registros";
    }
    $resultado->close();
    $mysql->close();

    
            $date = date('Y-m-d H:i:s');           
            $user = mysqli_real_escape_string($conexion, $_POST['usuario']);
            $clave = md5(mysqli_real_escape_string($conexion, $_POST['clave']));
            $query = mysqli_query($conexion, "SELECT * FROM usuario WHERE usuario = '$user' AND clave = '$clave' AND estado = 1");
          // mysqli_close($conexion);
            $resultado = mysqli_num_rows($query);
            

            if ($resultado > 0) {
                $dato = mysqli_fetch_array($query);
                $_SESSION['active'] = true;
                $_SESSION['idUser'] = $dato['idusuario'];
                $_SESSION['nombre'] = $dato['nombre'];
                $_SESSION['user'] = $dato['usuario'];
                $idusuario = $dato['idusuario'];

                 $query2 = mysqli_query($conexion, "INSERT INTO fecha_ingreso(fecha,idusuario) values ('$date','$idusuario') ");

                   mysqli_close($conexion);
                   */