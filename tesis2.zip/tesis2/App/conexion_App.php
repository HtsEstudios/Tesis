<?php

$mysql=new mysqli("localhost","root","","bd_happyanimals2");
if($mysql->connect_error){
    die("Error de conexion");
}
else{
    //echo "Conexion exitosa";
}

?>

